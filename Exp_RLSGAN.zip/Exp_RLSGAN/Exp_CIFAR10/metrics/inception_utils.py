import tensorflow as tf
import tensorflow_gan as tfgan
import os

INCEPTION_URL = "http://download.tensorflow.org/models/frozen_inception_v1_2015_12_05.tar.gz"
INCEPTION_FROZEN_GRAPH = "inceptionv1_for_inception_score.pb"


# def get_inception_graph_def():
#   return tfgan.eval.get_graph_def_from_url_tarball(  # pylint: disable=unreachable
#       url=INCEPTION_URL,
#       filename=INCEPTION_FROZEN_GRAPH,
#       tar_filename=os.path.basename(INCEPTION_URL))


def get_activations(inputs):
  return tfgan.eval.run_inception(inputs)['pool_3'].eval()


def get_logits(inputs):
    return tfgan.eval.run_inception(inputs)['logits'].eval()