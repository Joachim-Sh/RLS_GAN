# Code derived from tensorflow/tensorflow/models/image/imagenet/classify_image.py
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os.path
import tarfile

import numpy as np
from six.moves import urllib
import tensorflow as tf
import tensorflow_gan as tfg
import tensorflow_hub as hub
import math
import sys
import scipy as sp
import os
import gzip, pickle
from matplotlib.pyplot import imread
import pathlib
import urllib

MODEL_DIR = '/tmp/imagenet'
DATA_URL = 'http://download.tensorflow.org/models/image/imagenet/inception-2015-12-05.tgz'
softmax = None
pool3 = None


class InvalidFIDException(Exception):
    pass


def calculate_FID_from_images(real_images, fake_images, batch_size = 100):
    with tf.Session() as s:
        mu_real, sigma_real = calculate_activation_statistics(real_images, s, batch_size=batch_size)
        mu_fake, sigma_fake = calculate_activation_statistics(fake_images, s, batch_size=batch_size)
        d = calculate_frechet_distance(mu_fake, sigma_fake, mu_real, sigma_real)
    return d


def calculate_activation_statistics(images, sess, batch_size=50, verbose=False):
    """Calculation of the statistics used by the FID.
    Params:
    -- images      : Numpy array of dimension (n_images, hi, wi, 3). The values
                     must lie between 0 and 255.
    -- sess        : current session
    -- batch_size  : the images numpy array is split into batches with batch size
                     batch_size. A reasonable batch size depends on the available hardware.
    -- verbose     : If set to True and parameter out_step is given, the number of calculated
                     batches is reported.
    Returns:
    -- mu    : The mean over samples of the activations of the pool_3 layer of
               the incption model.
    -- sigma : The covariance matrix of the activations of the pool_3 layer of
               the incption model.
    """
    act = get_activations(images, sess, batch_size, verbose)
    mu = np.mean(act, axis=0)
    sigma = np.cov(act, rowvar=False)
    return mu, sigma


def calculate_frechet_distance(mu1, sigma1, mu2, sigma2):
    """Numpy implementation of the Frechet Distance.
    The Frechet distance between two multivariate Gaussians X_1 ~ N(mu_1, C_1)
    and X_2 ~ N(mu_2, C_2) is
            d^2 = ||mu_1 - mu_2||^2 + Tr(C_1 + C_2 - 2*sqrt(C_1*C_2)).
    Params:
    -- mu1 : Numpy array containing the activations of the pool_3 layer of the
             inception net ( like returned by the function 'get_predictions')
    -- mu2   : The sample mean over activations of the pool_3 layer, precalcualted
               on an representive data set.
    -- sigma2: The covariance matrix over activations of the pool_3 layer,
               precalcualted on an representive data set.
    Returns:
    -- dist  : The Frechet Distance.
    Raises:
    -- InvalidFIDException if nan occures.
    """
    m = np.square(mu1 - mu2).sum()
    s = sp.linalg.sqrtm(np.dot(sigma1, sigma2))
    dist = m + np.trace(sigma1+sigma2 - 2*s)
    if np.isnan(dist):
        raise InvalidFIDException("nan occured in distance calculation.")
    return dist


def get_activations(images, sess, batch_size=50, verbose=False):
    """Calculates the activations of the pool_3 layer for all images.
    Params:
    -- images      : Numpy array of dimension (n_images, hi, wi, 3). The values
                     must lie between 0 and 256.
    -- sess        : current session
    -- batch_size  : the images numpy array is split into batches with batch size
                     batch_size. A reasonable batch size depends on the disposable hardware.
    -- verbose    : If set to True and parameter out_step is given, the number of calculated
                     batches is reported.
    Returns:
    -- A numpy array of dimension (num images, 2048) that contains the
       activations of the given tensor when feeding inception with the query tensor.
    """
    inception_layer = pool3
    d0 = images.shape[0]
    if batch_size > d0:
        print("warning: batch size is bigger than the data size. setting batch size to data size")
        batch_size = d0
    n_batches = d0//batch_size
    n_used_imgs = n_batches*batch_size
    pred_arr = np.empty((n_used_imgs,2048))
    for i in range(n_batches):
        # if verbose:
            # print("\rPropagating batch %d/%d" % (i+1, n_batches), end="", flush=True)
            # print("\rPropagating batch %d/%d" % (i+1, n_batches))

        start = i*batch_size
        end = start + batch_size
        batch = images[start:end]
        pred = sess.run(inception_layer, {'InputTensor:0': batch})
        pred_arr[start:end] = pred.reshape(batch_size,-1)
    # if verbose:
    #     print(" done")
    return pred_arr


# Call this function with list of images. Each of elements should be a
# numpy array with values ranging from 0 to 255.
def get_inception_score(images, splits=10, bs = 100):
  # assert(type(images) == list)
  # assert(type(images[0]) == np.ndarray)
  assert(len(images[0].shape) == 3)
  # assert(np.max(images[0]) > 10)
  # assert(np.min(images[0]) >= 0.0)
  inps = []
  for img in images:
    img = img.astype(np.float32)
    inps.append(np.expand_dims(img, 0))
  with tf.Session() as sess:
    preds = []
    n_batches = int(math.ceil(float(len(inps)) / float(bs)))
    for i in range(n_batches):
        sys.stdout.write(".")
        sys.stdout.flush()
        inp = inps[(i * bs):min((i + 1) * bs, len(inps))]
        inp = np.concatenate(inp, 0)
        pred = sess.run(softmax, {'InputTensor:0': inp})
        preds.append(pred)
    preds = np.concatenate(preds, 0)
    scores = []
    for i in range(splits):
      part = preds[(i * preds.shape[0] // splits):((i + 1) * preds.shape[0] // splits), :]
      kl = part * (np.log(part) - np.log(np.expand_dims(np.mean(part, 0), 0)))
      kl = np.mean(np.sum(kl, 1))
      scores.append(np.exp(kl))
    return np.mean(scores), np.std(scores)

# This function is called automatically.
def _init_inception():
  global softmax, pool3
  if not os.path.exists(MODEL_DIR):
    os.makedirs(MODEL_DIR)
  filename = DATA_URL.split('/')[-1]
  filepath = os.path.join(MODEL_DIR, filename)
  if not os.path.exists(filepath):
    def _progress(count, block_size, total_size):
      sys.stdout.write('\r>> Downloading %s %.1f%%' % (
          filename, float(count * block_size) / float(total_size) * 100.0))
      sys.stdout.flush()
    filepath, _ = urllib.request.urlretrieve(DATA_URL, filepath, _progress)
    print()
    statinfo = os.stat(filepath)
    print('Succesfully downloaded', filename, statinfo.st_size, 'bytes.')
  tarfile.open(filepath, 'r:gz').extractall(MODEL_DIR)
  with tf.gfile.FastGFile(os.path.join(
      MODEL_DIR, 'classify_image_graph_def.pb'), 'rb') as f:
    graph_def = tf.GraphDef()
    graph_def.ParseFromString(f.read())
    # Import model with a modification in the input tensor to accept arbitrary
    # batch size.
    input_tensor = tf.placeholder(tf.float32, shape=[None, None, None, 3],
                                  name='InputTensor')
    _ = tf.import_graph_def(graph_def, name='',
                            input_map={'ExpandDims:0':input_tensor})
  # Works with an arbitrary minibatch size.
  with tf.Session() as sess:
    pool3 = sess.graph.get_tensor_by_name('pool_3:0')
    ops = pool3.graph.get_operations()
    for op_idx, op in enumerate(ops):
        for o in op.outputs:
            shape = o.get_shape()
            shape = [s.value for s in shape]
            new_shape = []
            for j, s in enumerate(shape):
                if s == 1 and j == 0:
                    new_shape.append(None)
                else:
                    new_shape.append(s)
            o.set_shape(tf.TensorShape(new_shape))
    w = sess.graph.get_operation_by_name("softmax/logits/MatMul").inputs[1]
    logits = tf.matmul(tf.squeeze(pool3, [1, 2]), w)
    softmax = tf.nn.softmax(logits)


## TF2

def batch_generator(X, batch_size=32, drop_remainder=False):
    assert batch_size > 0
    i = 0
    while i + batch_size <= X.shape[0]:
        yield X[i:i + batch_size]
        i = i + batch_size
    if i < X.shape[0] and not drop_remainder:  # yield remaining elements smaller than batch_size
        yield X[i:]

class InceptionScorer:

    def __init__(self):
        self.tfhub_inception = 'https://tfhub.dev/tensorflow/tfgan/eval/inception/1'
        self.inception_layer = hub.KerasLayer(self.tfhub_inception)
        self.cached_fid_real_outputs = None

    def __kl_divergence(self, p, p_logits, q):
        x = p * (tf.nn.log_softmax(p_logits) - tf.math.log(q))
        return tf.reduce_sum(x, axis=1)

    # @tf.function
    def __get_output(self, batch,final_layer, session=None):
        if session is not None:
          out = session.run(self.inception_layer(batch)[final_layer])
        else:
          out = self.inception_layer(batch)[final_layer]
        if final_layer == 'pool_3':
            out = tf.squeeze(out)
        return out

    def get_outputs(self, images, batch_size, final_layer, session=None):
      all_outputs = []
      for batch in batch_generator(images, batch_size=batch_size):
          out = self.__get_output(batch, final_layer, session=session)
          all_outputs.append(out)
      return tf.concat(all_outputs,axis=0)

    def inception_score(self,images, batch_size=1):
        all_logits = self.get_outputs(images, batch_size, 'logits')
        logits = tf.concat(all_logits, axis=0)
        p = tf.nn.softmax(logits)
        q = tf.reduce_mean(input_tensor=p, axis=0)
        kl = self.__kl_divergence(p, logits, q)
        return tf.exp(tf.reduce_mean(kl))

    def frechet_inception_distance(self, real_images, fake_images, batch_size=1, cache_real_output = False, session=None):
        if cache_real_output:
            if self.cached_fid_real_outputs is None:
                self.cached_fid_real_outputs = self.get_outputs(real_images, batch_size, 'pool_3')
            all_outputs1 = self.cached_fid_real_outputs
        else:
            all_outputs1 = self.get_outputs(real_images, batch_size, 'pool_3')
        all_outputs2 = self.get_outputs(fake_images, batch_size, 'pool_3')
        all_outputs1 = tf.reshape(all_outputs1, (-1, tf.shape(all_outputs1)[-1]))
        all_outputs2 = tf.reshape(all_outputs2, (-1, tf.shape(all_outputs2)[-1]))
        result = tfg.eval.frechet_classifier_distance_from_activations(all_outputs1,all_outputs2)
        if session is not None:
            result = session.run(result)
        return result


if softmax is None:
  _init_inception()


