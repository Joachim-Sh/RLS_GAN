# Leverage Score Sampling for Complete Mode Coverage in Generative Adversarial Networks

This repo is implemented upon and has the same dependencies as the official [StyleGAN2 + DiffAugment repo](https://github.com/mit-han-lab/data-efficient-gans). Specifically,

- TF records for the unbalanced CIFAR10 dataset can be downloaded from: https://www.dropbox.com/s/mqc1ohzt2bn7cjw/TFRecords_UnbalancedCIFAR10.zip?dl=0 
- TensorFlow 1.15 with GPU support.
- `tensorflow-datasets` version <= 2.1.0 should be installed to run on CIFAR, e.g., `pip install tensorflow-datasets==2.1.0`.
- You also require the UMAP python package, `pip install umap-learn`
- If you are facing problems with `nvcc` (when building custom ops of StyleGAN2), this can be circumvented by specifying `--impl=ref` in training at the cost of a slightly longer training time.


## CIFAR-10 

To run the CIFAR experiments:

```bash
python run_cifar.py --dataset=WHICH_DATASET --total-kimg=5000 --num-gpus=1 --resolution=32 --rls=[0 = no RLS sampling / 1 = Inception network feature map + UMAP / 2 = Discriminator feature map + sketching] --DiffAugment=color,translation,cutout --metrics=""
```

`WHICH_DATASET` specifies the path to the `unbalanced` dataset (folder with tf-records).`NUM_GPUS` specifies the number of GPUs to use.


### Evaluation

To evaluate a model , run the following command:

```bash
python run_cifar.py --dataset=WHICH_DATASET --resume=WHICH_MODEL --eval --metrics='fid10k,is10k'
```

`WHICH_DATASET` specifies the path to the `balanced` dataset (folder with tf-records). `WHICH_MODEL` specifies the path to the model (pkl file)

Counting the number of generated samples is done by running the `EvaluateCifar.ipynb` notebook. The notebook requires a npy file with generated samples in the CIFAR_Results folder.

