# Copyright (c) 2019, NVIDIA Corporation. All rights reserved.
#
# This work is made available under the Nvidia Source Code License-NC.
# To view a copy of this license, visit
# https://nvlabs.github.io/stylegan2/license.html

"""Loss functions."""

import tensorflow as tf
from dnnlib.tflib.autosummary import autosummary
from DiffAugment_tf import DiffAugment


# Matrix square root using the Newton-Schulz method
def sqrt_newton_schulz(A, iterations=20, dtype='float64'):
    dim = tf.shape(A)[0]
    normA = tf.norm(A)
    Y = tf.divide(A, normA)
    I = tf.eye(dim, dtype=dtype)
    Z = tf.eye(dim, dtype=dtype)
    for i in range(iterations):
        T = 0.5 * (3.0 * I - Z @ Y)
        Y = Y @ T
        Z = T @ Z
    sqrtA = Y * tf.sqrt(normA)
    return sqrtA

def wasserstein_bures_kernel(fake_phi, real_phi, sqrtm_func=sqrt_newton_schulz, epsilon=10e-14, normalize=True , dtype='float64',weight=1.):
    if dtype == 'float64':
        fake_phi = tf.cast(fake_phi, tf.float64)
        real_phi = tf.cast(real_phi, tf.float64)

    batch_size = tf.shape(fake_phi)[0]

    # Center and normalize
    fake_phi = fake_phi - tf.ones(shape=(batch_size, 1), dtype=dtype) @ tf.math.reduce_mean(fake_phi, axis=0, keepdims=True)
    real_phi = real_phi - tf.ones(shape=(batch_size, 1), dtype=dtype) @ tf.math.reduce_mean(real_phi, axis=0, keepdims=True)
    if normalize:
        fake_phi = tf.nn.l2_normalize(fake_phi, 1)
        real_phi = tf.nn.l2_normalize(real_phi,1)

    K11 = fake_phi @ tf.transpose(fake_phi)
    K11 = K11 + epsilon * tf.eye(batch_size, dtype=dtype)
    K22 = real_phi @ tf.transpose(real_phi)
    K22 = K22 + epsilon * tf.eye(batch_size, dtype=dtype)

    K12 = fake_phi @ tf.transpose(real_phi) + epsilon * tf.eye(batch_size, dtype=dtype)

    bures = tf.linalg.trace(K11) + tf.linalg.trace(K22) - 2 * tf.linalg.trace(sqrtm_func(K12 @ tf.transpose(K12)))

    return weight * bures

def wasserstein_bures_covariance(fake_phi, real_phi, epsilon=10e-14, sqrtm_func=sqrt_newton_schulz, normalize=True,
                                 dtype='float64', weight=1.):
    if dtype == 'float64':
        fake_phi = tf.cast(fake_phi, tf.float64)
        real_phi = tf.cast(real_phi, tf.float64)

    batch_size = tf.shape(fake_phi)[0]
    h_dim = tf.shape(fake_phi)[1]

    # Center and normalize
    fake_phi = fake_phi - tf.ones(shape=(batch_size, 1), dtype=dtype) @ tf.math.reduce_mean(fake_phi, axis=0,
                                                                                            keepdims=True)
    real_phi = real_phi - tf.ones(shape=(batch_size, 1), dtype=dtype) @ tf.math.reduce_mean(real_phi, axis=0,
                                                                                            keepdims=True)
    if normalize:
        fake_phi = tf.nn.l2_normalize(fake_phi, 1)
        real_phi = tf.nn.l2_normalize(real_phi, 1)

    # bures
    C1 = tf.transpose(fake_phi) @ fake_phi
    C1 = C1 + epsilon * tf.eye(h_dim, dtype=dtype)
    C2 = tf.transpose(real_phi) @ real_phi
    C2 = C2 + epsilon * tf.eye(h_dim, dtype=dtype)

    bures = tf.linalg.trace(C1) + tf.linalg.trace(C2) - 2 * tf.linalg.trace(sqrtm_func(C1 @ C2))

    return weight * bures


def ns_DiffAugment_r1(G, D, training_set, minibatch_size, reals, gamma=10, policy='', **kwargs):
    latents = tf.random_normal([minibatch_size] + G.input_shapes[0][1:])
    labels = training_set.get_random_labels_tf(minibatch_size)
    fakes = G.get_output_for(latents, labels, is_training=True)

    real_scores, _ = D.get_output_for(DiffAugment(reals, policy=policy, channels_first=True), is_training=True)
    fake_scores, _ = D.get_output_for(DiffAugment(fakes, policy=policy, channels_first=True), is_training=True)
    real_scores = autosummary('Loss/scores/real', real_scores)
    fake_scores = autosummary('Loss/scores/fake', fake_scores)

    G_loss = tf.nn.softplus(-fake_scores)
    G_loss = autosummary('Loss/G_loss', G_loss)
    D_loss = tf.nn.softplus(fake_scores) + tf.nn.softplus(-real_scores)
    D_loss = autosummary('Loss/D_loss', D_loss)

    with tf.name_scope('GradientPenalty'):
        real_grads = tf.gradients(tf.reduce_sum(real_scores), [reals])[0]
        gradient_penalty = tf.reduce_sum(tf.square(real_grads), axis=[1, 2, 3])
        gradient_penalty = autosummary('Loss/gradient_penalty', gradient_penalty)
        D_reg = gradient_penalty * (gamma * 0.5)
    return G_loss, D_loss, D_reg


def ns_DiffAugment_r1_bures(G, D, training_set, minibatch_size, reals, gamma=10, policy='', **kwargs):
    latents = tf.random_normal([minibatch_size] + G.input_shapes[0][1:])
    labels = training_set.get_random_labels_tf(minibatch_size)
    fakes = G.get_output_for(latents, labels, is_training=True)

    real_scores, phi_real = D.get_output_for(DiffAugment(reals, policy=policy, channels_first=True), is_training=True)
    fake_scores, phi_fake = D.get_output_for(DiffAugment(fakes, policy=policy, channels_first=True), is_training=True)
    # _, phi_real = D.get_output_for(reals, is_training=True)
    # _, phi_fake = D.get_output_for(fakes, is_training=True)
    real_scores = autosummary('Loss/scores/real', real_scores)
    fake_scores = autosummary('Loss/scores/fake', fake_scores)

    D_bures = wasserstein_bures_kernel(phi_fake, phi_real)
    G_loss = tf.nn.softplus(-fake_scores) + tf.cast(D_bures, tf.float32)
    G_loss = autosummary('Loss/G_loss', G_loss)
    D_loss = tf.nn.softplus(fake_scores) + tf.nn.softplus(-real_scores)
    D_loss = autosummary('Loss/D_loss', D_loss)

    with tf.name_scope('GradientPenalty'):
        real_grads = tf.gradients(tf.reduce_sum(real_scores), [reals])[0]
        gradient_penalty = tf.reduce_sum(tf.square(real_grads), axis=[1, 2, 3])
        gradient_penalty = autosummary('Loss/gradient_penalty', gradient_penalty)
        D_reg = gradient_penalty * (gamma * 0.5)
    return G_loss, D_loss, D_reg


def ns_r1_DiffAugment(G, D, training_set, minibatch_size, reals, gamma=10, policy='', **kwargs):
    latents = tf.random_normal([minibatch_size] + G.input_shapes[0][1:])
    labels = training_set.get_random_labels_tf(minibatch_size)
    fakes = G.get_output_for(latents, labels, is_training=True)

    reals = DiffAugment(reals, policy=policy, channels_first=True)
    fakes = DiffAugment(fakes, policy=policy, channels_first=True)
    real_scores, _ = D.get_output_for(reals, is_training=True)
    fake_scores, _ = D.get_output_for(fakes, is_training=True)
    real_scores = autosummary('Loss/scores/real', real_scores)
    fake_scores = autosummary('Loss/scores/fake', fake_scores)

    G_loss = tf.nn.softplus(-fake_scores)
    G_loss = autosummary('Loss/G_loss', G_loss)
    D_loss = tf.nn.softplus(fake_scores) + tf.nn.softplus(-real_scores)
    D_loss = autosummary('Loss/D_loss', D_loss)

    with tf.name_scope('GradientPenalty'):
        real_grads = tf.gradients(tf.reduce_sum(real_scores), [reals])[0]
        gradient_penalty = tf.reduce_sum(tf.square(real_grads), axis=[1, 2, 3])
        gradient_penalty = autosummary('Loss/gradient_penalty', gradient_penalty)
        D_reg = gradient_penalty * (gamma * 0.5)
    return G_loss, D_loss, D_reg

# ----------------------------------------------------------------------------
