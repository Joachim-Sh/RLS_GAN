import itertools
import os
import sys
import tarfile
import urllib
from abc import ABC, abstractmethod
import numpy as np
from scipy import stats
import tensorflow_probability as tfp
from numpy.random import default_rng
from sklearn.metrics.pairwise import rbf_kernel
from tensorflow.keras.models import Model
from lib import models, evaluate
import umap

from .linalg import *

initial_random_seed = 42
lambdaReg = 1e-4

def getLambdaReg():
    return lambdaReg

def setLambdaReg(newVal):
    global lambdaReg 
    lambdaReg = newVal


def eye(batch_size, dtype='float64'):
    if dtype == 'float64':
        arr = tf.eye(batch_size, dtype='float64')
    else:
        arr = tf.eye(batch_size)
    return arr


def sample_normal(batch, dim, dtype='float64'):
    if dtype == 'float64':
        noise = tf.random.normal([batch, dim], dtype='float64')
    else:
        noise = tf.random.normal([batch, dim])
    return noise
    
def gauss_pdf(x):
  mu1 = -10
  mu2 = 0
  mu3 = 10
  std = 0.5
  return 0.05 * stats.norm.pdf(x, loc = mu1, scale = std) + 0.9 * stats.norm.pdf(x, loc = mu2, scale = std) + 0.05 * stats.norm.pdf(x, loc = mu3, scale = std)
  
def gauss_pdf_True(x):
  mu1 = -10
  mu2 = 0
  mu3 = 10
  std = 0.5
  return (1/3) * stats.norm.pdf(x, loc = mu1, scale = std) + (1/3) * stats.norm.pdf(x, loc = mu2, scale = std) + (1/3) * stats.norm.pdf(x, loc = mu3, scale = std)
  
def randdist(x, pdf, nvals):
    """Produce nvals random samples from pdf(x), assuming constant spacing in x."""

    # get cumulative distribution from 0 to 1
    cumpdf = np.cumsum(pdf)
    cumpdf *= 1/cumpdf[-1]

    # input random values
    randv = np.random.uniform(size=nvals)

    # find where random values would go
    idx1 = np.searchsorted(cumpdf, randv)
    # get previous value, avoiding division by zero below
    idx0 = np.where(idx1==0, 0, idx1-1)
    idx1[idx0==0] = 1

    # do linear interpolation in x
    frac1 = (randv - cumpdf[idx0]) / (cumpdf[idx1] - cumpdf[idx0])
    randdist = x[idx0]*(1-frac1) + x[idx1]*frac1

    return randdist

def sample_Gaussian(batch):
    N = 10000
    x = np.linspace(-15,15,N)
    y = gauss_pdf(x) 
    rvs = randdist(x, y, batch)
    rvs = np.reshape(rvs, (-1, 1))
    probs_X = gauss_pdf(rvs)
    probs_X_true = gauss_pdf_True(rvs)
    return np.asarray(rvs).astype('float32'), np.asarray(probs_X_true/ probs_X).astype('float32')


def sample_ring(batch_size, unbalanced=False, n_mixture=8, std=0.05, radius=2.5, random_seed=initial_random_seed,
                mean=(0, 0),nmbUnbalanced = 4, ratio = 0.05):
    """Generate 2D Ring"""
    # thetas = np.linspace(0, 2 * np.pi, n_mixture)
    thetas = np.linspace(0, 2 * np.pi, n_mixture + 1)[:-1]  # extra mode compared to gdpp paper
    xs, ys = mean[0] + radius * np.sin(thetas, dtype='float32'), mean[1] + radius * np.cos(thetas, dtype='float32')
    if unbalanced:
        #probs = np.logspace(startLog, 1, num=n_mixture)
        # probs = np.linspace(0.1, 1, num=n_mixture) # probabilities not small enough
        probs = np.ones(n_mixture, dtype='float32')
        probs[0:nmbUnbalanced] = ratio
        cat = tfp.distributions.Categorical(probs=probs)
    else:
        cat = tfp.distributions.Categorical(tf.zeros(n_mixture))
    cat_True = tfp.distributions.Categorical(tf.zeros(n_mixture))
    comps = [tfp.distributions.MultivariateNormalDiag([xi, yi], [std, std]) for xi, yi in zip(xs.ravel(), ys.ravel())]
    data = tfp.distributions.Mixture(cat, comps)
    data_True = tfp.distributions.Mixture(cat_True, comps)
    samples = data.sample(batch_size, seed=random_seed)
    probs_X = data.prob(samples)
    probs_X_True = data_True.prob(samples)
    return np.asarray(samples), probs/np.sum(probs), np.asarray(probs_X_True/ probs_X).reshape((-1,1))


def sample_grid(batch_size, unbalanced=False, num_components=25, std=0.05, random_seed=initial_random_seed,nmbUnbalanced = 5, ratio = 0.05):
    """Generate 2D Grid"""
    if unbalanced:
        probs = np.ones(num_components, dtype='float32')
        probs[0:nmbUnbalanced] = ratio
        cat = tfp.distributions.Categorical(probs=probs)
    else:
        probs = np.ones(num_components) / num_components
        cat = tfp.distributions.Categorical(tf.zeros(num_components, dtype=tf.float32))
    cat_True = tfp.distributions.Categorical(tf.zeros(num_components, dtype=tf.float32))
    mus = np.array([np.array([i, j]) for i, j in itertools.product(range(-4, 5, 2),
                                                                   range(-4, 5, 2))], dtype=np.float32)
    sigmas = [np.array([std, std]).astype(np.float32) for i in range(num_components)]
    components = list((tfp.distributions.MultivariateNormalDiag(mu, sigma)
                       for (mu, sigma) in zip(mus, sigmas)))
    data = tfp.distributions.Mixture(cat, components)
    data_True = tfp.distributions.Mixture(cat_True, components)
    samples = data.sample(batch_size, seed=random_seed)
    probs_X = data.prob(samples)
    probs_X_True = data_True.prob(samples)
    return np.asarray(samples), probs/np.sum(probs), np.asarray(probs_X_True/ probs_X).reshape((-1,1))
    
def sample_MNIST(unbalanced=False, ratioProb = 1/100, UnbalancedClass = [0,1,2], Classes = np.arange(10)):
    """Generate MNIST"""
    X, Y = load_mnist_images()
    X = np.asarray(X)
    Y = np.asarray(Y)
    nmbClass = len(Classes)
    nmbUnbalanced = len(UnbalancedClass)
    removClasses = np.arange(10)
    removClasses = np.delete(removClasses,Classes)
    if nmbClass < 10:
        for i in removClasses:
            idx_i = np.argwhere(Y == i)
            X = np.delete(X,idx_i,axis=0)
            Y = np.delete(Y,idx_i)
    if unbalanced is True:
        for i in UnbalancedClass:
            idx_i = np.argwhere(Y == i)
            idx_reduced = np.round(len(idx_i)*ratioProb).astype('int32')
            idx_i = idx_i[idx_reduced+1:]
            X = np.delete(X,idx_i,axis=0)
            Y = np.delete(Y,idx_i)
        probs_X = np.ones(len(Y))
        for i in UnbalancedClass:
            idx_i = np.argwhere(Y == i)
            probs_X[idx_i] = ratioProb
        probs_X = probs_X / np.sum(probs_X)
    else:
        probs_X = np.ones(len(Y)) / np.sum(len(Y))
    probs_X_True = np.ones(len(Y)) / np.sum(len(Y))
    return X,Y, np.asarray(probs_X_True/ probs_X).reshape((-1,1)).astype('float32')
  
    

def sample_row_gaussians(batch_size, std=0.05, num_components=5, probabilities=None, delta_mu=2, random_seed=initial_random_seed):
    if probabilities is None:
        cat = tfp.distributions.Categorical(tf.zeros(num_components, dtype=tf.float32))
    else:
        cat = tfp.distributions.Categorical(probs=probabilities)
    mus = [(delta_mu*i) for i in range(num_components)]
    mus = (mus - np.mean(mus)).astype('float32')
    mus = [(m,0) for m in mus] # row on y=0
    sigmas = [np.array([std, std]).astype(np.float32) for _ in range(num_components)]
    components = list((tfp.distributions.MultivariateNormalDiag(mu, sigma)
                       for (mu, sigma) in zip(mus, sigmas)))
    data = tfp.distributions.Mixture(cat, components)
    return np.asarray(data.sample(batch_size, seed=random_seed))


def sample_batch_uniformTF(batch_size, X):
    """Sample Data Uniform"""
    sizeX = tf.shape(X)
    idx = tf.random.uniform(shape=[batch_size], minval=0, maxval=sizeX[0], dtype=tf.int32)
    return tf.gather(X, idx)

def sample_batch_uniform(batch_size, X, np_generator = None):
    """Sample Data Uniform"""
    if np_generator is None:
        np_generator = default_rng()
    idx = np_generator.choice(X.shape[0],batch_size,replace=False)
    return X[idx], tf.cast(idx, tf.int32)
    
def sample_batch_weighted(batch_size, X, weights):
    """Sample Data weighted"""
    ls = tf.math.divide(weights, tf.math.reduce_sum(weights))
    idx = tf.squeeze(tf.random.categorical(tf.math.log([ls]), batch_size))
    idx = tf.cast(idx, tf.int32)
    return X, weights, idx 


def load_mnist_images():
    (train_images, train_labels), (_, _) = tf.keras.datasets.mnist.load_data()
    train_images = train_images.reshape(train_images.shape[0], 28, 28, 1).astype('float32')
    X = (train_images - 127.5) / 127.5  # Normalize the images to [-1, 1]
    return np.asarray(X), np.asarray(train_labels)



def sample_batch_LS(batch_size, X, discriminator_feature_map, featuremapSampling = 'discriminator', bw =None,twoStep = None, s = None):
    """Sample Data Leverage"""
    np_generator = default_rng()
    #ridgeParam = X.shape[0] * getLambdaReg()
    if twoStep is not None:
        twoStepSampleSize = twoStep*batch_size
        if twoStepSampleSize > X.shape[0]:
            twoStepSampleSize = X.shape[0]
        idx_unif = np_generator.choice(X.shape[0],twoStepSampleSize,replace=False)
        X = X[idx_unif] # Two step sampling procedure
    if featuremapSampling is 'linear':
        phiX = tf.cast(X, tf.float64)
        if phiX.shape[0] > phiX.shape[1]:
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            dual = False
        else:
            K = phiX @ tf.transpose(phiX)  # matrix multiplication
            dual = True
    elif featuremapSampling is 'discriminator':
        phiX = discriminator_feature_map(X, training=False)
        phiX = tf.cast(phiX, tf.float64)
        if phiX.shape[0] > phiX.shape[1]:
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            dual = False
        else:
            K = phiX @ tf.transpose(phiX)  # matrix multiplication
            dual = True
    elif featuremapSampling is 'discriminator_sketched':
        phiX = discriminator_feature_map(X, training=False)
        S = tf.random.normal([phiX.shape[1], s]) / tf.math.sqrt(s + 0.0)
        phiX = phiX @ S 
        phiX = tf.cast(phiX, tf.float64)
        if phiX.shape[0] > phiX.shape[1]:
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            dual = False
        else:
            K = phiX @ tf.transpose(phiX)  # matrix multiplication
            dual = True
    elif featuremapSampling is 'discriminator_UMAP':
        phiX = discriminator_feature_map(X, training=False)
        reducer = umap.UMAP(n_components=s)
        phiX = reducer.fit_transform(phiX)
        phiX = tf.cast(phiX, tf.float64)
        if phiX.shape[0] > phiX.shape[1]:
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            dual = False
        else:
            K = phiX @ tf.transpose(phiX)  # matrix multiplication
            dual = True            
    elif featuremapSampling is 'gaussianAdapt' or featuremapSampling is 'gaussian':
        K = rbf_kernel(X, X, gamma=(1/(2 * bw**2)))
        dual = True
    if dual is False:
        sizeC = C.shape
        ridgeParam = X.shape[0] * getLambdaReg()
        F = tf.linalg.cholesky(C + ridgeParam * eye(sizeC[0]))  # Use cholesky instead
        B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
        ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
        ls_orig = ls
    else:
        ridgeParam = K.shape[0] * getLambdaReg()
        sizeK = K.shape
        R = tf.linalg.cholesky(K + ridgeParam * eye(sizeK[0]))  # Use cholesky instead
        B = tf.linalg.cholesky_solve(R, K)
        ls = tf.linalg.diag_part(B)
        ls_orig = ls
    ls = tf.math.divide(ls, tf.math.reduce_sum(ls))
    idx = tf.squeeze(tf.random.categorical(tf.math.log([ls]), batch_size))
    idx = tf.cast(idx, tf.int32)
    return X, ls_orig, idx


def batch_generator(X, batch_size=32, drop_remainder=False):
    assert batch_size > 0
    i = 0
    while i + batch_size <= X.shape[0]:
        yield X[i:i + batch_size], tf.range(i, i + batch_size)
        i = i + batch_size
    if i < X.shape[0] and not drop_remainder:  # yield remaining elements smaller than batch_size
        yield X[i:] , tf.range(i, X.shape[0]) 


def epoch_batch_generator(batch_size, X):
    batch_cache_ds = tf.data.Dataset.from_tensor_slices(X).repeat(None).batch(batch_size=batch_size,
                                                                           drop_remainder=False)
    for batch in batch_cache_ds:
        yield batch


def uniform_sampler_generator(batch_size, X, cache_nr, np_generator = None):
    if batch_size > X.shape[0]:
        batch_size = X.shape[0]
    if cache_nr < batch_size:
        cache_nr = batch_size
    sample_cache, idx_cache = sample_batch_uniform(cache_nr, X, np_generator=np_generator)
    for batch, idx in batch_generator(sample_cache, batch_size, drop_remainder=True):
        yield batch, tf.gather(idx_cache, idx)
        
def weighted_sampler_generator(batch_size, X, weights, cache_nr):
    if batch_size > X.shape[0]:
        batch_size = X.shape[0]
    if cache_nr < batch_size:
        cache_nr = batch_size
    X_cache, ls_cache , idx_cache = sample_batch_weighted(cache_nr, X, weights)
    sample_cache = tf.gather(X_cache, idx_cache)
    ls_cache = tf.math.divide(ls_cache, tf.math.reduce_sum(ls_cache))
    ls_cache = tf.gather(ls_cache, idx_cache)
    for batch, idx in batch_generator(sample_cache, batch_size, drop_remainder=True):
        weights = 1 / tf.sqrt(tf.gather(ls_cache, idx))
        weights = tf.math.divide(weights, tf.math.reduce_sum(weights)) # normalize weights
        yield batch, weights


def LS_sampler_generator(batch_size, X, cache_nr, feature_map, featuremapSampling, bw, twoStep, s):
    if batch_size > X.shape[0]:
        batch_size = X.shape[0]
    if cache_nr < batch_size:
        cache_nr = batch_size
    X_cache, ls_cache , idx_cache = sample_batch_LS(cache_nr, X, feature_map, featuremapSampling, bw, twoStep, s)
    sample_cache = tf.gather(X_cache, idx_cache)
    ls_cache = tf.math.divide(ls_cache, tf.math.reduce_sum(ls_cache))
    ls_cache = tf.gather(ls_cache, idx_cache)
    for batch, idx in batch_generator(sample_cache, batch_size, drop_remainder=True):
        weights = 1 / tf.sqrt(tf.gather(ls_cache, idx))
        weights = tf.math.divide(weights, tf.math.reduce_sum(weights)) # normalize weights
        yield batch, weights


"sample_cache_nr: integer,'all' or 'batch'. Sets how many samples should be precalculated. " \
"   An integer means how many samples i.e. indices in the first dimension."
"   'all' is a shortcut for X.shape[0] and batch is a shortcut for a cache equal to a single batch size."
"force_equal_batch_size: if true then all batches will have the same number of samples," \
" if false then the remainder will also be a batch i.e. if the number of samples is not divisible by the batch size. "


class Sampler(ABC):
    def __init__(self, batch_size, X, gan, sample_cache_nr='None', force_equal_batch_size=True):
        if batch_size > X.shape[0]:
            batch_size = X.shape[0]
        self.batch_size = batch_size
        self.X = X
        self.gan = gan
        if sample_cache_nr == 'all':
            sample_cache_nr = X.shape[0]
        if sample_cache_nr == 'batch' or sample_cache_nr is None or sample_cache_nr < batch_size :
            sample_cache_nr = batch_size
        self.sample_cache_nr = sample_cache_nr
        self.force_equal_batch_size = force_equal_batch_size

    @abstractmethod
    def sample_batch(self):
        ...

    def sample(self, nr):
        batches = []
        indices = []
        for _ in range(nr):
            batch, idx =  self.sample_batch()
            batches.append(batch)
            indices.append(idx)
        return batches, indices

    @classmethod
    def create(cls, name, batch_size, X, gan, sample_cache_nr = None, kwargs = None):
        name = name.lower()
        if name == 'uniform':
            if kwargs is not None:
                return UniformSampler(batch_size, X, gan, sample_cache_nr, **kwargs)
            else:
                return UniformSampler(batch_size, X, gan, sample_cache_nr)
        elif name == 'shuffle':
            if kwargs is not None:
                return ShuffleSampler(batch_size, X, gan, sample_cache_nr, **kwargs)
            else:
                return ShuffleSampler(batch_size, X, gan, sample_cache_nr)
        elif name == 'epoch':
            if kwargs is not None:
                return EpochBatchSampler(batch_size, X, gan, sample_cache_nr, **kwargs)
            else:
                return EpochBatchSampler(batch_size, X, gan, sample_cache_nr)
        elif name == 'npuniform':
            if kwargs is not None:
                return NumpyUniformSampler(batch_size, X, gan, sample_cache_nr, **kwargs)
            else:
                return NumpyUniformSampler(batch_size, X, gan, sample_cache_nr)
        elif name == 'npweighted':
            if kwargs is not None:
                return NumpyWeightedSampler(batch_size, X, gan, sample_cache_nr, **kwargs)
            else:
                return NumpyWeightedSampler(batch_size, X, gan, sample_cache_nr)
        elif name == 'ls' or name == 'LS' or name == 'leveragescore':
            if kwargs is not None:
                return LSSampler(batch_size, X, gan, sample_cache_nr, **kwargs)
            else:
                return LSSampler(batch_size, X, gan, sample_cache_nr)
        else:
            raise AssertionError('Invalid sampler name.')


class GeneratorSampler(Sampler):
    def __init__(self, batch_size, X, gan, sample_cache_nr='all'):
        super().__init__(batch_size, X, gan, sample_cache_nr)
        self.generator_callable, self.generator_callable_args = self._create_generator()
        self.dataset, self.dataset_iterator = self._create_dataset()

    @abstractmethod
    def _create_generator(self):
        ...

    def _create_dataset(self):
        batch_generator = self.generator_callable
        args = self.generator_callable_args
        dataset = tf.data.Dataset.from_generator(batch_generator, args=args,
                                                 output_shapes=(self.batch_size,) + self.X.shape[1:],
                                                 output_types='float32').repeat(None)
        dataset_iterator = iter(dataset)
        return dataset, dataset_iterator

    def sample_batch(self):
        return next(self.dataset_iterator)


class UniformSampler(GeneratorSampler):

    def __init__(self, batch_size, X, gan, sample_cache_nr='all'):
        super().__init__(batch_size, X, gan, sample_cache_nr)

    def _create_generator(self):
        return uniform_sampler_generator, [self.batch_size, self.X, self.sample_cache_nr]


# infinitly goes through the data sequentially for a specific batch size
class EpochBatchSampler(Sampler):

    def __init__(self, batch_size, X, gan = None, sample_cache_nr='all'):
        super().__init__(batch_size, X, gan, sample_cache_nr)
        self.ds = tf.data.Dataset.from_tensor_slices(X).batch(batch_size=batch_size, drop_remainder=False).repeat(None)
        self.ds_iterator = iter(self.ds)

    def sample_batch(self):
        return next(self.ds_iterator)


class DataSampler(Sampler):

    def __init__(self, batch_size, X, gan, sample_cache_nr='None', force_equal_batch_size=True):
        super().__init__(batch_size, X, gan, sample_cache_nr , force_equal_batch_size)
        self.dataset, self.dataset_iterator = self._create_dataset()

    def _create_dataset(self, repeat=1):
        samples = self._sample_x(self.sample_cache_nr)
        dataset = tf.data.Dataset.from_tensor_slices(samples).repeat(repeat).batch(batch_size=self.batch_size,
                                                                                   drop_remainder=self.force_equal_batch_size)
        dataset_iterator = iter(dataset)
        return dataset, dataset_iterator

    @abstractmethod
    def _sample_x(self, nr=1):
        ...

    def _take_or_reconstruct(self):
        sample = next(self.dataset_iterator, None)
        if sample is None:
            self._create_dataset()
            sample = next(self.dataset_iterator)
        return sample

    def sample_batch(self):
        return self._take_or_reconstruct()

    'Resamples nr samples. Does not make use of the cached samples'

    def sample(self, nr=1):
        return self._sample_x(nr)


class ShuffleSampler(DataSampler):

    def __init__(self, batch_size, X, gan, sample_cache_nr='all', force_equal_batch_size=True):
        super().__init__(batch_size, X, gan, sample_cache_nr, force_equal_batch_size)

    def _create_dataset(self, repeat=None):
        samples = self._sample_x(self.sample_cache_nr)
        dataset = tf.data.Dataset.from_tensor_slices(samples).repeat(repeat).shuffle(self.sample_cache_nr).batch(
            batch_size=self.batch_size,
            drop_remainder=self.force_equal_batch_size)
        dataset_iterator = iter(dataset)
        return dataset, dataset_iterator

    def _sample_x(self, nr=1):
        if nr == self.X.shape[0]:
            return self.X
        else:
            return self.X[:nr]

class NumpyUniformSampler(Sampler):

    def __init__(self, batch_size, X, gan, sample_cache_nr='all', force_equal_batch_size=True):
        super().__init__(batch_size, X, gan, sample_cache_nr, force_equal_batch_size)
        self.np_generator = default_rng()
        self.dataset_iterator = uniform_sampler_generator(self.batch_size,self.X, self.sample_cache_nr, np_generator=self.np_generator)

    def sample_batch(self):
        b, weights = next(self.dataset_iterator, (None,None))
        if b is None:
            self.dataset_iterator = uniform_sampler_generator(self.batch_size,self.X, self.sample_cache_nr)
            b, weights = next(self.dataset_iterator)
        return b, weights
        
class NumpyWeightedSampler(Sampler):

    def __init__(self, batch_size, X, gan, sample_cache_nr='all', force_equal_batch_size=True, weights = None):
        super().__init__(batch_size, X, gan, sample_cache_nr, force_equal_batch_size)
        self.np_generator = default_rng()
        if weights == None:
            weights = np.ones(X.shape[0]) / X.shape[0]
        self.weights = weights
        self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)

    def sample_batch(self): 
        b, weights = next(self.dataset_iterator, (None,None))
        if b is None:
            self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X , self.weights, self.sample_cache_nr)
            b, weights = next(self.dataset_iterator)
        return b, weights

class LSSampler(Sampler):

    def __init__(self, batch_size, X, gan, sample_cache_nr='none', featuremapSampling = 'discriminator', bw = None, twoStep = None, s = None, force_equal_batch_size=True    
                ,cnn_mnist_model_location='data/cnn_model_checkpoint.hdf5'):
        super().__init__(batch_size, X, gan, sample_cache_nr, force_equal_batch_size)
        self.featuremapSampling = featuremapSampling
        self.bw = bw
        self.twoStep = twoStep
        self.s = s
        if featuremapSampling is 'gaussian':
            # Pre-calculate the leverage scores
            K = rbf_kernel(X, X, gamma=(1/ (2 * bw**2)))
            ridgeParam = X.shape[0] * getLambdaReg()
            sizeK = K.shape
            R = tf.linalg.cholesky(K + ridgeParam * eye(sizeK[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(R, K)
            ls = tf.linalg.diag_part(B)
            self.weights = ls
            self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)
        elif featuremapSampling is 'linear':
            phiX = np.reshape(X,(X.shape[0], 28 * 28))
            phiX = tf.cast(phiX, tf.float64)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            self.weights = ls
            self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)
        elif featuremapSampling is 'mnist_sketched':
            # Pre-calculate the leverage scores
            if len(X.shape) == 2:
                X_reshaped = X.reshape((X.shape[0], 28, 28, 1))
            else:
                X_reshaped = X
            cnn = models.mnist_cnn()
            cnn.load_weights(cnn_mnist_model_location)
            cnnFeaturemap = Model(cnn.input, cnn.layers[-3].output)
            phiX =  cnnFeaturemap.predict(X_reshaped, batch_size=batch_size)
            S = tf.random.normal([phiX.shape[1], s]) / tf.math.sqrt(s + 0.0)
            phiX = phiX @ S 
            phiX = tf.cast(phiX, tf.float64)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            self.weights = ls
            self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)
        elif featuremapSampling is 'inception_sketched':
            # Pre-calculate the leverage scores
            inception_scorer = evaluate.InceptionScorer()
            if X.shape[3] == 1:
                X_scaled = np.tile(X,3)
            else:
                X_scaled = X
            phiX = inception_scorer._get_outputs(X_scaled, batch_size=1, final_layer='pool_3')
            if tf.rank(phiX[0]) == 1:
                phiX = tf.convert_to_tensor(phiX)
            else:
                phiX = tf.concat(phiX,axis=0)
            S = tf.random.normal([phiX.shape[1], s]) / tf.math.sqrt(s + 0.0)
            phiX = phiX @ S
            phiX = tf.cast(phiX, tf.float64)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            self.weights = ls
            self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)
        elif featuremapSampling is 'mnist_UMAP':
            # Pre-calculate the leverage scores
            if len(X.shape) == 2:
                X_reshaped = X.reshape((X.shape[0], 28, 28, 1))
            else:
                X_reshaped = X
            cnn = models.mnist_cnn()
            cnn.load_weights(cnn_mnist_model_location)
            cnnFeaturemap = Model(cnn.input, cnn.layers[-3].output)
            phiX =  cnnFeaturemap.predict(X_reshaped, batch_size=batch_size)
            reducer = umap.UMAP(n_components=s)
            phiX = reducer.fit_transform(phiX)
            phiX = tf.cast(phiX, tf.float64)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            self.weights = ls
            self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)
        elif featuremapSampling is 'inception_UMAP':
            # Pre-calculate the leverage scores
            inception_scorer = evaluate.InceptionScorer()
            if X.shape[3] == 1:
                X_scaled = np.tile(X,3)
            else:
                X_scaled = X
            phiX = inception_scorer._get_outputs(X_scaled, batch_size=1, final_layer='pool_3')
            if tf.rank(phiX[0]) == 1:
                phiX = tf.convert_to_tensor(phiX)
            else:
                phiX = tf.concat(phiX,axis=0)
            reducer = umap.UMAP(n_components=s)
            phiX = reducer.fit_transform(phiX)
            phiX = tf.cast(phiX, tf.float64)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            self.weights = ls
            self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)            
        else:
            self.dataset_iterator = LS_sampler_generator(self.batch_size,self.X, self.sample_cache_nr, self.gan.discriminator_feature_map, self.featuremapSampling, self.bw, self.twoStep, self.s)

    def sample_batch(self):
        b, weights = next(self.dataset_iterator, (None,None))
        if b is None:
            if self.featuremapSampling is 'gaussian' or self.featuremapSampling is 'mnist_sketched' or self.featuremapSampling is 'inception_sketched' or self.featuremapSampling is 'linear'or self.featuremapSampling is 'mnist_UMAP'  or self.featuremapSampling is 'inception_UMAP' :
                self.dataset_iterator = weighted_sampler_generator(self.batch_size,self.X, self.weights, self.sample_cache_nr)
            else:
                self.dataset_iterator = LS_sampler_generator(self.batch_size,self.X, self.sample_cache_nr, self.gan.discriminator_feature_map, 
                                                            self.featuremapSampling, self.bw, self.twoStep, self.s)
            b, weights = next(self.dataset_iterator)
        return b, weights



