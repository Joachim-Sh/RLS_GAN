import os

import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm
from tensorflow.keras.models import clone_model, Model
from sklearn.metrics.pairwise import rbf_kernel
from lib import losses, data, models, evaluate
from lib.logging import TensorboardLogger, save_samples, save_LS_1D, save_LS_2D, save_samples_as_images
import umap

default_adam_beta1 = 0.5
default_adam_learning_rate = 2e-4
default_z_sampler = tf.random.normal
default_x_sampler = 'npuniform'
cnn_mnist_model_location='data/cnn_model_checkpoint.hdf5'

def getLearningRate():
    return default_adam_learning_rate

def setLearningRate(newVal):
    global default_adam_learning_rate 
    default_adam_learning_rate = newVal


class GAN:

    def __init__(self, generator, discriminator, generator_optimizer=None,
                 discriminator_optimizer=None, generator_loss=losses.cross_entropy_generator_loss,
                 discriminator_loss=losses.cross_entropy_discriminator_loss, z_sampler=default_z_sampler,
                 x_sampler_method=default_x_sampler, x_sampler_args=None, name=None,sample_cache_nr=None, weightedLoss = False):
        if name is None:
            name = type(self).__name__ + '_' + str(x_sampler_method) + '_' + str(x_sampler_args).replace('.', '') + '_weighted_' + str(weightedLoss) 
        self.name = name
        self.generator = generator
        if type(discriminator) is tuple:
            self.discriminator = discriminator[0]
            self.discriminator_feature_map = discriminator[1]
        else:
            self.discriminator = discriminator
        if generator_optimizer is None:
            generator_optimizer = tf.keras.optimizers.Adam(beta_1=default_adam_beta1,
                                                           learning_rate=getLearningRate())
        self.generator_optimizer = generator_optimizer
        if discriminator_optimizer is None:
            discriminator_optimizer = tf.keras.optimizers.Adam(beta_1=default_adam_beta1,
                                                               learning_rate=getLearningRate())
        self.discriminator_optimizer = discriminator_optimizer
        self.generator_loss = generator_loss
        self.discriminator_loss = discriminator_loss
        self.z_dim = generator.input_shape[1]
        self.z_sampler = z_sampler
        self.x_sampler_method = x_sampler_method
        self.x_sampler = None
        self.sample_cache_nr = sample_cache_nr
        self.x_sampler_args = x_sampler_args
        self.weightedLoss = weightedLoss

    def update_discriminator(self, noise, real_batch):
        with tf.GradientTape() as disc_tape:
            generated_batch = self.generator(noise, training=False)
            real_y = self.discriminator(real_batch, training=True)
            fake_y = self.discriminator(generated_batch, training=True)
            disc_loss = self.discriminator_loss(real_y, fake_y)
        gradients_of_discriminator = disc_tape.gradient(disc_loss, self.discriminator.trainable_variables)
        self.discriminator_optimizer.apply_gradients(
            zip(gradients_of_discriminator, self.discriminator.trainable_variables))
        return disc_loss

    def update_generator(self, noise):
        with tf.GradientTape() as gen_tape:
            generated_batch = self.generator(noise, training=True)
            fake_y = self.discriminator(generated_batch, training=False)
            gen_loss = self.generator_loss(fake_y)
        gradients_of_generator = gen_tape.gradient(gen_loss, self.generator.trainable_variables)
        self.generator_optimizer.apply_gradients(zip(gradients_of_generator, self.generator.trainable_variables))
        return gen_loss

    def sample_generator(self, nr, batch_size=None):
        noise = self.z_sampler([nr, self.z_dim])
        if batch_size is None:
            return self.generator(noise, training=False)
        else:
            return self.generator.predict(noise, batch_size=batch_size)

    @tf.function
    def train_step(self, batch_size, x_batches, weights = None):
        noise = self.z_sampler([batch_size, self.z_dim])
        real_batch = x_batches[0]

        with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
            generated_batch = self.generator(noise, training=True)

            real_y = self.discriminator(real_batch, training=True)
            fake_y = self.discriminator(generated_batch, training=True)

            gen_loss = self.generator_loss(fake_y)
            if self.weightedLoss is False:
                disc_loss = self.discriminator_loss(real_y, fake_y)
            else:
                disc_loss = self.discriminator_loss(real_y, fake_y, weights = weights)
        gradients_of_generator = gen_tape.gradient(gen_loss, self.generator.trainable_variables)
        gradients_of_discriminator = disc_tape.gradient(disc_loss, self.discriminator.trainable_variables)

        self.generator_optimizer.apply_gradients(zip(gradients_of_generator, self.generator.trainable_variables))
        self.discriminator_optimizer.apply_gradients(
            zip(gradients_of_discriminator, self.discriminator.trainable_variables))
        return gen_loss, disc_loss

    def log_losses(self, logger, step, losses):
        logger.write_group([losses[0], losses[1]], group_name="losses", i=step,
                           names=['Generator_loss', 'Discriminator_loss'])

    def save_generator(self, logdir='out', name=None):
        if name is None:
            name = self.name
        save_path = os.path.join(logdir,'models', name)
        self.generator.save_weights(save_path)

    def load_generator(self, logdir='out', name=None):
        if name is None:
            name = self.name
        path = os.path.join(logdir, 'models', name)
        self.generator.load_weights(path)

    def _sample_x_batches(self):
        return self.x_sampler.sample(1)

    def train(self, X, batch_size=64, steps=50000, log_losses=False, logdir='out', save_samples_every=-1, probX = None):
        plot = save_samples_every > 0
        self.name = self.name + '_batch_' + str(batch_size)
        self.probX = probX
        logdir = os.path.join(logdir, self.name)

        if log_losses:
            logger = TensorboardLogger(logdir)

        if self.x_sampler is None: # is always set to None
            self.x_sampler = data.Sampler.create(self.x_sampler_method, batch_size, X, self, self.sample_cache_nr,  self.x_sampler_args)

        with tqdm(total=steps) as pbar:
            for step in range(steps):
                x_batches, weights = self._sample_x_batches()
                losses = self.train_step(batch_size, x_batches=x_batches, weights = weights)
                # save intermediate images
                if plot and (step % save_samples_every == 0):
                    save_samples(self.z_sampler, self.generator, X=X, root_dir=os.path.join(logdir, 'plots/'), filename='{}_{}'.format(self.name, step))               
                    if X.shape[1] > 2:
                        imgSize = np.sqrt(X.shape[1]).astype(int)
                        save_samples_as_images(x_batches[0],  root_dir=os.path.join(logdir, 'plots/'),filename ='miniBatch_{}_{}'.format(self.name, step), imgSize = imgSize)
                            
                # log tensorboard
                if log_losses:
                    self.log_losses(logger, step, losses)
                pbar.update()

        if plot:  # plot final result
            save_samples(self.z_sampler, self.generator, X=X,root_dir=os.path.join(logdir, 'plots/'), filename='{}_{}'.format(self.name, step))
                    
    def train_epochs(self, X, batch_size=32, epochs=10, log_losses=False, logdir='out', save_samples_every_epoch=False):
        logdir = os.path.join(logdir, self.name)

        if log_losses:
            logger = TensorboardLogger(logdir)

        # only supports the default epoch batch sampler
        self.x_sampler = data.Sampler.create("epoch", batch_size, X, None, None)

        batch_count = X.shape[0] // batch_size
        with tqdm(total=epochs) as pbar:
            for step in range(epochs):
                for _ in range(batch_count):
                    x_batches, weights = self._sample_x_batches()
                    losses = self.train_step(batch_size, x_batches=x_batches, weights = weights)
                    # log tensorboard
                    if log_losses:
                        self.log_losses(logger, step, losses)
                        # save intermediate images

                if save_samples_every_epoch:
                    save_samples(self.z_sampler, self.generator, X=X,
                                 root_dir=os.path.join(logdir, 'plots/'),
                                 filename='{}_{}'.format(self.name, step))
                pbar.update()

        if save_samples_every_epoch:  # plot final result
            save_samples(self.z_sampler, self.generator, X=X,
                         root_dir=os.path.join(logdir, 'plots/'), filename='{}_{}'.format(self.name, step))


class MWUGAN:

    def __init__(self, generator, discriminator, nmbGenerators, delta = 0.25, generator_optimizer=None,
                 discriminator_optimizer=None, generator_loss=losses.cross_entropy_generator_sigmoid, discriminator_loss=losses.cross_entropy_discriminator_loss_sigmoid, 
                 z_sampler=default_z_sampler, name=None,sample_cache_nr=None, weights = None, weightedLoss = False, sigma = 1, x_dim = None, nameDataset = None, 
                 Classes=None, labelsTrue = None, x_original = None, emb_real = None,minimumModes=150):
        " Implementation of Rethinking Generative Mode Coverage: A Pointwise Guaranteed Approach"
                     
        if name is None:
            if weights is None:
                name ='MWUGAN_' + str(nmbGenerators) + '_' + str(int(100 *delta))
            else:
                name ='LS_MWUGAN_' + str(weights) + '_' + str(nmbGenerators) + '_' + str(int(100 *delta)) + '_' + str(weightedLoss)
        self.name = name    
        self.nmbGenerators = nmbGenerators
        self.delta = 0.25
        self.generator = generator
        if type(discriminator) is tuple:
            self.discriminator = discriminator[0]
            self.discriminator_feature_map = discriminator[1]
        else:
            self.discriminator = discriminator
        if generator_optimizer is None:
            generator_optimizer = tf.keras.optimizers.Adam(beta_1=default_adam_beta1,
                                                           learning_rate=getLearningRate())
        self.generator_optimizer = generator_optimizer
        if discriminator_optimizer is None:
            discriminator_optimizer = tf.keras.optimizers.Adam(beta_1=default_adam_beta1,
                                                               learning_rate=getLearningRate())
        self.discriminator_optimizer = discriminator_optimizer
        self.generator_loss = generator_loss
        self.discriminator_loss = discriminator_loss
        self.z_dim = generator.input_shape[1]
        self.z_sampler = z_sampler
        self.sample_cache_nr = sample_cache_nr
        self.weights = weights
        self.weightedLoss = weightedLoss
        self.sigma = sigma
        self.x_dim = x_dim
        self.nameDataset = nameDataset
        self.nr_modes_captured = None
        self.perc_std = None
        self.Classes = Classes
        self.labelsTrue = labelsTrue
        self.x_original = x_original
        self.SWD = None
        self.emb_real = emb_real
        self.precision = None
        self.recall = None
        self.minimumModes = minimumModes


    def sample_generator(self, nr, batch_size=None):
        nmbGen = len(self.GANlist)
        prob = (1/nmbGen) * tf.ones(nmbGen)
        idx = tf.squeeze(tf.random.categorical(tf.math.log([prob]), nr))
        samples = None
        for i in range(nmbGen):
            samples_per_gan = np.sum(idx == i)
            currentGAN = self.GANlist[i]
            generated_batch = currentGAN.sample_generator(samples_per_gan)
            if samples is None:
                samples = generated_batch.numpy()
            else:
                samples = np.append(samples,generated_batch.numpy(), axis=0)
        
        return samples.astype('float32')
        
    def train(self, X, batch_size=64, steps=50000, log_losses=False, logdir='out', save_samples_every=-1, probX = None, x_original = None, Classes = None, labelsTrue = None, evalSamples = 10000):
        plot = save_samples_every > 0
        self.name = self.name + '_batch_' + str(int(batch_size))
        self.x_original = x_original
        self.Classes = Classes
        self.labelsTrue = labelsTrue

        logdir = os.path.join(logdir, self.name)

        if log_losses:
            logger = TensorboardLogger(logdir)
            
        if self.nameDataset is 'CIFAR10':
            inception_scorer = evaluate.InceptionScorer()
            
            
        # creating list        
        GANlist = [] 
        if self.weights is None:
            weights = (1 / X.shape[0]) * tf.ones(X.shape[0])
        elif self.weights is 'gaussian':
            K = rbf_kernel(X, X, gamma=(1/(2 * self.sigma**2)))
            ridgeParam = X.shape[0] * data.getLambdaReg()
            sizeK = K.shape
            R = tf.linalg.cholesky(K + ridgeParam * tf.eye(sizeK[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(R, K)
            ls = tf.linalg.diag_part(B)
            weights = ls / tf.reduce_sum(ls)
        elif self.weights is 'linear':
            phiX = np.reshape(X,(X.shape[0], 28 * 28))
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * data.getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * tf.eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            weights = ls / tf.reduce_sum(ls)
        elif self.weights is 'mnist_sketched':
            if len(X.shape) == 2:
                X_reshaped = X.reshape((X.shape[0], 28, 28))
            else:
                X_reshaped = X
            cnn = models.mnist_cnn()
            cnn.load_weights(cnn_mnist_model_location)
            cnnFeaturemap = Model(cnn.input, cnn.layers[-3].output)
            phiX =  cnnFeaturemap.predict(X_reshaped, batch_size=batch_size)
            S = tf.random.normal([phiX.shape[1], self.sigma]) / tf.math.sqrt(self.sigma + 0.0) # put dimension in sigma
            phiX = phiX @ S 
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * data.getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * tf.eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            weights = ls / tf.reduce_sum(ls)
        elif self.weights is 'inception_sketched':
            inception_scorer = evaluate.InceptionScorer()
            if X.shape[3] == 1:
                X_reshaped = np.tile(X,3)
            else:
                X_reshaped = X
            phiX = inception_scorer._get_outputs(X_reshaped, batch_size=1, final_layer='pool_3')
            if tf.rank(phiX[0]) == 1:
                phiX = tf.convert_to_tensor(phiX)
            else:
                phiX = tf.concat(phiX,axis=0)
            S = tf.random.normal([phiX.shape[1], self.sigma]) / tf.math.sqrt(self.sigma + 0.0)
            phiX = phiX @ S
            phiX = tf.cast(phiX, tf.float32)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * data.getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * tf.eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            weights = ls / tf.reduce_sum(ls)
        elif self.weights is 'mnist_UMAP':
            # Pre-calculate the leverage scores
            if len(X.shape) == 2:
                X_reshaped = X.reshape((X.shape[0], 28, 28, 1))
            else:
                X_reshaped = X
            cnn = models.mnist_cnn()
            cnn.load_weights(cnn_mnist_model_location)
            cnnFeaturemap = Model(cnn.input, cnn.layers[-3].output)
            phiX =  cnnFeaturemap.predict(X_reshaped, batch_size=batch_size)
            phiX = tf.cast(phiX, tf.float32)
            reducer = umap.UMAP(n_components=self.sigma)
            phiX = reducer.fit_transform(phiX)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * data.getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * tf.eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            weights = ls / tf.reduce_sum(ls)
        elif self.weights is 'inception_UMAP':
            # Pre-calculate the leverage scores
            inception_scorer = evaluate.InceptionScorer()
            if X.shape[3] == 1:
                X_reshaped = np.tile(X,3)
            else:
                X_reshaped = X
            phiX = inception_scorer._get_outputs(X_reshaped, batch_size=1, final_layer='pool_3')
            if tf.rank(phiX[0]) == 1:
                phiX = tf.convert_to_tensor(phiX)
            else:
                phiX = tf.concat(phiX,axis=0)
            phiX = tf.cast(phiX, tf.float32)
            reducer = umap.UMAP(n_components=self.sigma)
            phiX = reducer.fit_transform(phiX)
            C = tf.transpose(phiX) @ phiX  # matrix multiplication
            sizeC = C.shape
            ridgeParam = X.shape[0] * data.getLambdaReg()
            F = tf.linalg.cholesky(C + ridgeParam * tf.eye(sizeC[0]))  # Use cholesky instead
            B = tf.linalg.cholesky_solve(F, tf.transpose(phiX))
            ls = tf.reduce_sum(phiX * tf.transpose(B), axis=1)
            weights = ls / tf.reduce_sum(ls)
        else:
            raise ValueError('Weight function not implemented')
            
            
        for T in range(self.nmbGenerators):

            # Create GAN
            currentGAN = GAN(clone_model(self.generator), clone_model(self.discriminator), name='GAN_' + str(T), discriminator_loss= self. discriminator_loss, 
                            generator_loss = self.generator_loss, x_sampler_method='npweighted',x_sampler_args= {"weights" : weights}, weightedLoss = self.weightedLoss)
                            
            currentGAN.train(X, batch_size, steps=steps, save_samples_every=1000, log_losses=False, logdir=logdir)
            GANlist.append(currentGAN)
            self.GANlist = GANlist  
            
            # update weights
            confidence = tf.squeeze(currentGAN.discriminator(X, training=False)) # we expect a sigmoid output
            

            
            last_sum =  tf.math.reduce_sum(weights)
            Booleanvec = []
            terms = []
            for i in range(confidence.shape[0]):
                c_conf = confidence[i]
                a = 1/(c_conf + 1e-8) - 1
                last_p = weights[i]
                p0 = last_p/last_sum
                term = a * p0 * confidence.shape[0]
                terms.append(term)
                if(term < self.delta):
                    Booleanvec.append(1)
                else:
                    Booleanvec.append(0)
                   

            weights =  weights + (Booleanvec * weights)
            
            # Intermediate evaluation
            samples = self.sample_generator(evalSamples)
            int_dir = os.path.join(logdir, 'nmbGen_' + str(T))
            if self.nameDataset is 'Ring':
                if T == 0:
                    self.nr_modes_captured = np.zeros(self.nmbGenerators)
                    self.perc_std = np.zeros(self.nmbGenerators)
                nr_modes_captured, percentage_within_3std, samples_per_mode = evaluate.evaluate_ring(samples,root_dir=int_dir)
                self.nr_modes_captured[T] = nr_modes_captured
                self.perc_std[T] = percentage_within_3std
                
            elif self.nameDataset is 'Grid':
                if T == 0:
                    self.nr_modes_captured = np.zeros(self.nmbGenerators)
                    self.perc_std = np.zeros(self.nmbGenerators)
                nr_modes_captured, percentage_within_3std, samples_per_mode = evaluate.evaluate_grid(samples,root_dir=int_dir)
                self.nr_modes_captured[T] = nr_modes_captured
                self.perc_std[T] = percentage_within_3std
                
            elif self.nameDataset is 'MNIST':
                if T == 0:
                    self.nr_modes_captured = np.zeros(self.nmbGenerators)
                    self.perc_std = np.zeros(self.nmbGenerators)
                nr_modes_captured, KL_div, samples_per_mode = evaluate.evaluate_MNIST(samples,self.labelsTrue,root_dir=int_dir,Classes=self.Classes,minimumModesMNIST = self.minimumModes)
                self.nr_modes_captured[T] = nr_modes_captured
                self.perc_std[T] = KL_div
                
        
        samples = self.sample_generator(nr = 10000)
        save_samples(self.z_sampler, self.generator, X=X, root_dir= logdir, filename=self.name, generated_samples = samples)
        
            
class DiverseGAN(GAN):

    def __init__(self, generator, discriminator_with_feature_map, generator_optimizer=None,
                 discriminator_optimizer=None, generator_loss=losses.cross_entropy_generator_loss,
                 discriminator_loss=losses.cross_entropy_discriminator_loss, z_sampler=default_z_sampler, 
                 x_sampler_method=default_x_sampler, x_sampler_args=None, name=None, sample_cache_nr=None, weightedLoss = False, diversity_loss_func=None):
        super().__init__(generator, discriminator_with_feature_map, generator_optimizer, discriminator_optimizer,
                         generator_loss, discriminator_loss, z_sampler, x_sampler_method=x_sampler_method,
                         x_sampler_args=x_sampler_args, name=name, weightedLoss = weightedLoss)
        self.diversity_loss_func = diversity_loss_func
        if diversity_loss_func is None or diversity_loss_func is None:
            raise AssertionError("DiverseGAN requires a discriminator feature map and a diversity loss function.")

    def log_losses(self, logger, step, losses):
        tmp = 1

    @tf.function
    def train_step(self, batch_size, x_batches, weights = None):
        noise = self.z_sampler([batch_size, self.z_dim])
        real_batch = x_batches[0]
        with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
            generated_batch = self.generator(noise, training=True)

            real_y = self.discriminator(real_batch, training=True)
            fake_y = self.discriminator(generated_batch, training=True)

            phi_real = self.discriminator_feature_map(real_batch, training=True)
            phi_fake = self.discriminator_feature_map(generated_batch, training=True)

            diversity_loss = self.diversity_loss_func(phi_fake, phi_real)
            gen_cross_entropy = self.generator_loss(fake_y)
            gen_cross_entropy = tf.cast(gen_cross_entropy, tf.float64)
            gen_loss = 0.5 * (gen_cross_entropy + diversity_loss)
            if self.weightedLoss is False:
                disc_loss = self.discriminator_loss(real_y, fake_y)
            else:
                disc_loss = self.discriminator_loss(real_y, fake_y, weights = weights)

        gradients_of_generator = gen_tape.gradient(gen_loss, self.generator.trainable_variables)
        gradients_of_discriminator = disc_tape.gradient(disc_loss, self.discriminator.trainable_variables)

        self.generator_optimizer.apply_gradients(zip(gradients_of_generator, self.generator.trainable_variables))
        self.discriminator_optimizer.apply_gradients(
            zip(gradients_of_discriminator, self.discriminator.trainable_variables))

        return gen_cross_entropy, disc_loss, diversity_loss

class BuresGAN(DiverseGAN):

    def __init__(self, generator, discriminator_with_feature_map, generator_optimizer=None,
                 discriminator_optimizer=None, generator_loss=losses.cross_entropy_generator_loss,
                 discriminator_loss=losses.cross_entropy_discriminator_loss, z_sampler=default_z_sampler,
                 x_sampler_method=default_x_sampler, x_sampler_args=None, name=None ,sample_cache_nr=None, weightedLoss = False , diversity_loss_func=None,
                 dual=True):
        if diversity_loss_func is None:
            if dual:
                diversity_loss_func = losses.wasserstein_bures_kernel
            else:
                diversity_loss_func = losses.wasserstein_bures_covariance
        super().__init__(generator, discriminator_with_feature_map, generator_optimizer, discriminator_optimizer,
                         generator_loss, discriminator_loss, z_sampler, x_sampler_method, x_sampler_args, name, sample_cache_nr, 
                         weightedLoss, diversity_loss_func)



class PACGAN(GAN):


    def __init__(self, generator, discriminator, generator_optimizer=None, discriminator_optimizer=None,
                 generator_loss=losses.cross_entropy_generator_loss, discriminator_loss=losses.cross_entropy_discriminator_loss, 
                 z_sampler=default_z_sampler, x_sampler_method=default_x_sampler, x_sampler_args=None, name=None, sample_cache_nr='all' , pack_nr=2):
        super().__init__(generator, discriminator, generator_optimizer, discriminator_optimizer, generator_loss,
                         discriminator_loss, z_sampler, x_sampler_method, x_sampler_args, name)
        self.pack_nr = pack_nr

    def _sample_x_batches(self): # batch dimension is the same but pack_nr batches will be packed in the last dimension
        samples = self.x_sampler.sample(self.pack_nr) # Shape is 2 x 2 (samples, weights)
        n_batches = samples[0]
        s = n_batches[0].shape
        if len(s) == 3: # add extra dim for grayscale images
            n_batches = [np.expand_dims(b,-1) for b in n_batches]
        return [np.concatenate(n_batches, axis=-1)], None # concatenate in channels axis, or as a feature for 1d vector input

    @tf.function
    def train_step(self, batch_size, x_batches, weights = None):
        noise_batches = [self.z_sampler([batch_size, self.z_dim]) for _ in range(self.pack_nr)]
        real_batch = x_batches[0]

        with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
            generated_batches = [self.generator(noise, training=True) for noise in noise_batches]
            if len(generated_batches[0].shape) == 3:
                generated_batches = [tf.expand_dims(b,-1) for b in generated_batches]
            generated_batch = tf.concat(generated_batches, axis=-1)

            real_y = self.discriminator(real_batch, training=True)
            fake_y = self.discriminator(generated_batch, training=True)

            gen_loss = self.generator_loss(fake_y)
            disc_loss = self.discriminator_loss(real_y, fake_y)

        gradients_of_generator = gen_tape.gradient(gen_loss, self.generator.trainable_variables)
        gradients_of_discriminator = disc_tape.gradient(disc_loss, self.discriminator.trainable_variables)

        self.generator_optimizer.apply_gradients(zip(gradients_of_generator, self.generator.trainable_variables))
        self.discriminator_optimizer.apply_gradients(
            zip(gradients_of_discriminator, self.discriminator.trainable_variables))
        return gen_loss, disc_loss
        
class IWMMDGAN(GAN):

    def __init__(self, generator, discriminator_with_feature_map, generator_optimizer=None,
                 discriminator_optimizer=None, generator_loss=losses.cross_entropy_generator_loss,
                 discriminator_loss=losses.cross_entropy_discriminator_loss, z_sampler=default_z_sampler, 
                 x_sampler_method=default_x_sampler, x_sampler_args=None, name=None, sample_cache_nr=None, estimator = 'sniw', probX = None):
        super().__init__(generator, discriminator_with_feature_map, generator_optimizer, discriminator_optimizer,
                         generator_loss, discriminator_loss, z_sampler, x_sampler_method=x_sampler_method,
                         x_sampler_args=x_sampler_args, name=name)
                         
        self.estimator = estimator
        self.probX = probX
        
    def sample_generator(self, nr, batch_size=None):
        noise = self.z_sampler([nr, self.z_dim])
        if batch_size is None:
            return self.generator(noise, training=False) * self.X_std + self.X_mean
        else:
            return self.generator.predict(noise, batch_size=batch_size) * self.X_std + self.X_mean
        
    def upper(self,mat):
        return tf.linalg.band_part(mat, 0, -1) - tf.linalg.band_part(mat, 0, 0)

    def compute_mmd_weighted(self, input1, input2, input1_weights):
        """Computes MMD between two batches of d-dimensional inputs.
        
        In this setting, input1 is real and input2 is generated, so input1 
        has weights.
        """
        
        # Resize for images
        if len(input1.shape) > 2:
            input1 = tf.reshape(input1,(input1.shape[0], np.prod(input1.shape[1:])))
        if len(input2.shape) > 2:
            input2 = tf.reshape(input2,(input2.shape[0], np.prod(input2.shape[1:])))
        
        estimator = self.estimator
        batch_size = input1.shape[0]
        num_combos_xx = batch_size * (batch_size - 1) / 2
        num_combos_yy = batch_size * (batch_size - 1) / 2
    
        v = tf.concat([input1, input2], 0)
        VVT = tf.matmul(v, tf.transpose(v))
        sqs = tf.reshape(tf.linalg.diag_part(VVT), [-1, 1])
        sqs_tiled_horiz = tf.tile(sqs, tf.transpose(sqs).get_shape())
        exp_object = sqs_tiled_horiz - 2 * VVT + tf.transpose(sqs_tiled_horiz)
        
        K = 0
        sigma_list = [0.01, 1.0, 2.0]
        for sigma in sigma_list:
            #gamma = 1.0 / (2.0 * sigma ** 2)
            K += tf.exp(-0.5 * (1 / sigma) * exp_object)
        K_xx = K[:batch_size, :batch_size]
        K_yy = K[batch_size:, batch_size:]
        K_xy = K[:batch_size, batch_size:]
        K_xx_upper = self.upper(K_xx)
        K_yy_upper = self.upper(K_yy)
    
        ######################
        # Originally written like this.
        #x_unnormed = v[:batch_size, :1] * data_raw_std[0] + data_raw_mean[0]
        #weights_x = 1. / thinning_fn(x_unnormed)
        #weights_x_tiled_horiz = tf.tile(weights_x, [1, batch_size])
        #p1_weights = weights_x_tiled_horiz
        #p2_weights = tf.transpose(p1_weights) 
        #p1p2_weights = p1_weights * p2_weights
        #p1p2_weights_upper = upper(p1p2_weights)
        #p1p2_weights_upper_normed = p1p2_weights_upper / tf.reduce_sum(p1p2_weights_upper)
        #p1_weights_normed = p1_weights / tf.reduce_sum(p1_weights)
        #Kw_xx_upper = K_xx * p1p2_weights_upper_normed
        #Kw_xy = K_xy * p1_weights_normed
    
        if estimator == 'iw':
            # Importance-weighted.
            weights_tiled_horiz = tf.tile(input1_weights, [1, batch_size])
            p1_weights = weights_tiled_horiz
            p2_weights = tf.transpose(p1_weights) 
            p1p2_weights = p1_weights * p2_weights
            p1p2_weights_upper = self.upper(p1p2_weights)
            Kw_xx_upper = K_xx * p1p2_weights_upper
            Kw_xy = K_xy * p1_weights
    
            mmd = (tf.reduce_sum(Kw_xx_upper) / num_combos_xx +
                   tf.reduce_sum(K_yy_upper) / num_combos_yy -
                   2 * tf.reduce_mean(Kw_xy))
    
        elif estimator == 'sniw':
            # Self-normalized weights.
            weights_tiled_horiz = tf.tile(input1_weights, [1, batch_size])
            p1_weights = weights_tiled_horiz
            p2_weights = tf.transpose(p1_weights) 
            p1p2_weights = p1_weights * p2_weights
            p1p2_weights_upper = self.upper(p1p2_weights)
            p1p2_weights_upper_normed = p1p2_weights_upper / tf.reduce_sum(p1p2_weights_upper)
            p1_weights_normed = p1_weights / tf.reduce_sum(p1_weights)
            Kw_xx_upper = K_xx * p1p2_weights_upper_normed
            Kw_xy = K_xy * p1_weights_normed
    
            mmd = (tf.reduce_sum(Kw_xx_upper) +
                   tf.reduce_sum(K_yy_upper) / num_combos_yy -
                   2 * tf.reduce_sum(Kw_xy))
    
        return mmd

    @tf.function
    def train_step(self, batch_size, x_batches, weights = None):
        noise = self.z_sampler([batch_size, self.z_dim])
        real_batch = x_batches[0]
        idx_weights = weights[0]
        mmd_weights = tf.gather(self.probX, idx_weights) # weights contain the selected indices
 
        with tf.GradientTape() as gen_tape:
            generated_batch = self.generator(noise, training=True)
            mmd_loss = self.compute_mmd_weighted(real_batch, generated_batch, mmd_weights)
            gen_loss = mmd_loss
            disc_loss = 0 # discriminator is not trained

        gradients_of_generator = gen_tape.gradient(gen_loss, self.generator.trainable_variables)
        self.generator_optimizer.apply_gradients(zip(gradients_of_generator, self.generator.trainable_variables))

        return gen_loss, disc_loss
        
    def train(self, X, batch_size=64, steps=50000, log_losses=False, logdir='out', save_samples_every=-1, probX = None):
        plot = save_samples_every > 0
        self.name = self.name + '_batch_' + str(batch_size)
        self.probX = probX
        logdir = os.path.join(logdir, self.name)
        
        # Normalize data 
        self.X_mean = np.mean(X, axis=0)
        self.X_std = np.std(X, axis=0)
        self.X_std[self.X_std == 0] = 1 # Do not change zero std values
        X_normed = (X - self.X_mean) / self.X_std

        if log_losses:
            logger = TensorboardLogger(logdir)

        if self.x_sampler is None: # is always set to None
            self.x_sampler = data.Sampler.create(self.x_sampler_method, batch_size, X_normed, self, self.sample_cache_nr,  self.x_sampler_args)

        with tqdm(total=steps) as pbar:
            for step in range(steps):
                x_batches, weights = self._sample_x_batches()
                losses = self.train_step(batch_size, x_batches=x_batches, weights = weights)
                # save intermediate images
                if plot and (step % save_samples_every == 0):
                    if self.generator.output_shape[1] < 3:
                        generated_samples = self.sample_generator(2500)
                    else:
                        generated_samples = self.sample_generator(64)
                    save_samples(self.z_sampler, self.generator, X=X, root_dir=os.path.join(logdir, 'plots/'), filename='{}_{}'.format(self.name, step), 
                    generated_samples = generated_samples)
                    if X.shape[1] > 2:
                        save_samples_as_images(x_batches[0]*self.X_std + self.X_mean,root_dir=os.path.join(logdir, 'plots/'),filename ='miniBatch_{}_{}'.format(self.name, step))
                            
                # log tensorboard
                if log_losses:
                    self.log_losses(logger, step, losses)
                pbar.update()

        if plot:  # plot final result
            if self.generator.output_shape[1] < 3:
                generated_samples = self.sample_generator(2500) 
            else:
                generated_samples = self.sample_generator(64) 
            save_samples(self.z_sampler, self.generator, X=X,root_dir=os.path.join(logdir, 'plots/'), filename='{}_{}'.format(self.name, step), 
            generated_samples = generated_samples)
            
class IWGAN(GAN):

    def __init__(self, generator, discriminator_with_feature_map, generator_optimizer=None,
                 discriminator_optimizer=None, generator_loss=losses.cross_entropy_generator_loss,
                 discriminator_loss=losses.cross_entropy_discriminator_loss, z_sampler=default_z_sampler, 
                 x_sampler_method=default_x_sampler, x_sampler_args=None, name=None, sample_cache_nr=None, estimator = 'iw', probX = None):
        super().__init__(generator, discriminator_with_feature_map, generator_optimizer, discriminator_optimizer,
                         generator_loss, discriminator_loss, z_sampler, x_sampler_method=x_sampler_method,
                         x_sampler_args=x_sampler_args, name=name)
        self.estimator = estimator
        self.probX = probX
        
    @tf.function
    def train_step(self, batch_size, x_batches, weights = None):
        noise = self.z_sampler([batch_size, self.z_dim])
        real_batch = x_batches[0]

        with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
            generated_batch = self.generator(noise, training=True)

            real_y = self.discriminator(real_batch, training=True)
            fake_y = self.discriminator(generated_batch, training=True)

            gen_loss = self.generator_loss(fake_y)
            disc_loss = self.discriminator_loss(real_y, fake_y, weights = weights)
            
        gradients_of_generator = gen_tape.gradient(gen_loss, self.generator.trainable_variables)
        gradients_of_discriminator = disc_tape.gradient(disc_loss, self.discriminator.trainable_variables)

        self.generator_optimizer.apply_gradients(zip(gradients_of_generator, self.generator.trainable_variables))
        self.discriminator_optimizer.apply_gradients(
            zip(gradients_of_discriminator, self.discriminator.trainable_variables))
        return gen_loss, disc_loss        

    def train(self, X, batch_size=64, steps=50000, log_losses=False, logdir='out', save_samples_every=-1, probX = None):
        plot = save_samples_every > 0
        self.name = self.name + '_batch_' + str(batch_size)
        self.probX = probX
        logdir = os.path.join(logdir, self.name)

        if log_losses:
            logger = TensorboardLogger(logdir)

        if self.x_sampler is None: # is always set to None
            self.x_sampler = data.Sampler.create(self.x_sampler_method, batch_size, X, self, self.sample_cache_nr,  self.x_sampler_args)

        with tqdm(total=steps) as pbar:
            for step in range(steps):
                x_batches, idx = self._sample_x_batches()
                weights = tf.transpose(tf.gather(self.probX, idx[0]))
                if self.estimator is 'sniw':
                    weights = weights / tf.reduce_sum(weights)		
                losses = self.train_step(batch_size, x_batches=x_batches, weights = weights)
                # save intermediate images
                if plot and (step % save_samples_every == 0):
                    save_samples(self.z_sampler, self.generator, X=X, root_dir=os.path.join(logdir, 'plots/'), filename='{}_{}'.format(self.name, step))
                    if X.shape[1] > 2:
                        imgSize = np.sqrt(X.shape[1]).astype(int)
                        save_samples_as_images(x_batches[0],  root_dir=os.path.join(logdir, 'plots/'),filename ='miniBatch_{}_{}'.format(self.name, step), imgSize = imgSize)
                            
                # log tensorboard
                if log_losses:
                    self.log_losses(logger, step, losses)
                pbar.update()

        if plot:  # plot final result
            save_samples(self.z_sampler, self.generator, X=X,root_dir=os.path.join(logdir, 'plots/'), filename='{}_{}'.format(self.name, step))


