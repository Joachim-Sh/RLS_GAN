import tensorflow as tf
import re
import os
import matplotlib.pyplot as plt
import numpy as np
from lib import data
import matplotlib.style as style 
import matplotlib
import seaborn as sns

# Style
style.use('ggplot')
matplotlib.rcParams['font.family'] = "serif"
sns.set(font='serif')
sns.set_context("poster")  
plt.rc('xtick', labelsize=30)
plt.rc('ytick', labelsize=30)


class TensorboardLogger(object):
    path_regex = re.compile('[^\w\-_\. ]')

    def __init__(self, log_dir):
        self.log_dir = log_dir
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        self.writers = {}
        self.writer_groups = {}

    def __to_valid_name(self, s):
        return re.sub(self.path_regex, '_', s)

    def add_watch(self, tensor, name=None):
        if name is None:
            name = tensor.name
        summary_writer = tf.summary.create_file_writer(self.log_dir + "/{}".format(self.__to_valid_name(name)))
        self.writers[name] = summary_writer

    def add_watch_group(self, tensors, group_name, names=None):
        group = {}
        if names is None:
            names = [t.name for t in tensors]
        for tensor, name in zip(tensors, names):
            summary_writer = tf.summary.create_file_writer(
                self.log_dir + "/{}/{}".format(self.__to_valid_name(group_name), self.__to_valid_name(name)))
            group[name] = summary_writer
        self.writer_groups[group_name] = group

    def write(self, tensor, i, name=None):
        if name is None:
            name = tensor.name
        if name not in self.writers:
            self.add_watch(tensor)
        with self.writers[name].as_default():
            tf.summary.scalar(name=name, data=tensor, step=i)

    def write_group(self, tensors, i, group_name, names=None):
        if names is None:
            names = [t.name for t in tensors]
        if group_name not in self.writer_groups:
            self.add_watch_group(tensors, group_name, names)
        group = self.writer_groups[group_name]
        for tensor, name in zip(tensors, names):
            with group[name].as_default():
                tf.summary.scalar(name=group_name, data=tensor, step=i)

    def close(self):
        for writer in self.writers.values():
            writer.flush()
            writer.close()
        for group in self.writer_groups.values():
            for writer in group.values():
                writer.flush()
                writer.close()


def save_samples(z_sampler, generator, X=None, root_dir='plots/', filename='generated_samples', generated_samples = None):
    if not os.path.exists(root_dir):
        os.makedirs(root_dir)
    if generator.output_shape[1] < 3: # 2D
        sample_nr = 2500
    else:
        sample_nr = 64
    noise_dim = generator.input_shape[1]
    noise = z_sampler([sample_nr, noise_dim])
    real_samples = None
    if X is not None:
        real_samples, idx = data.sample_batch_uniform(sample_nr, X)
    if generated_samples is None:
        generated_samples = generator(noise, training=False)
    if generated_samples.shape[1] == 1:
        save_Gaussian1D(generated_samples, real_samples, root_dir, filename=filename)
    elif generated_samples.shape[1] == 2:
        save_samples_2d(generated_samples, real_samples, root_dir, filename=filename)
    else:
        save_samples_as_images(generated_samples, root_dir, filename=filename)

def save_samples_2d(generated_samples, real_samples=None, root_dir='plots/', filename='generated_samples'):
    save_loc = os.path.join(root_dir, filename)
    plt.figure(figsize=(5, 5))
    plt.scatter(generated_samples[:, 0], generated_samples[:, 1], edgecolor='none',alpha = 0.01)
    if real_samples is not None:
        plt.scatter(real_samples[:, 0], real_samples[:, 1], c='g', edgecolor='none',alpha = 0.01)
    plt.axis('off')
    plt.axis('equal') # forces the same ticks on axis, useful to prevent stretching of figures
    plt.savefig(save_loc, bbox_inches = 'tight')
    plt.clf()
    plt.close()


def save_Gaussian1D(generated_samples, real_samples=None, root_dir='plots/', filename='generated_samples'):
    if not os.path.exists(root_dir):
        os.makedirs(root_dir)
    x = np.linspace(-15,15,10000)
    y = data.gauss_pdf(x)
    if tf.is_tensor(generated_samples):
        generated_samples = generated_samples.numpy()
    generated_samples = generated_samples.flatten()
    save_loc = os.path.join(root_dir, filename)
    plt.hist(generated_samples.flatten(),bins = np.linspace(-15,15,50), density = True,label="Samples")
    plt.plot(x,y,label="ground truth")
    plt.legend(loc = 'upper right')
    plt.savefig(save_loc, bbox_inches = 'tight')
    plt.clf()
    plt.close()


def save_samples_as_images(samples, root_dir='plots/', filename='generated_samples',imgSize = None):
    save_loc = os.path.join(root_dir, filename)
    if len(samples.shape) == 2:
        if imgSize is None:
            imgSize = np.sqrt(samples.shape[1]).astype(int)
        samples = np.reshape(samples[:,:imgSize**2],(samples.shape[0],imgSize,imgSize))
    if len(samples.shape) == 3:
        samples = np.expand_dims(samples, -1)
    if samples.shape[3] == 1 or samples.shape[3] == 2:
        gray_scale = True
    else:
        gray_scale = False

    plt.figure(figsize=(5, 5))
    if samples.shape[0] >= 64:
        nmbMax = 64
    else:
        nmbMax = samples.shape[0]
    
    plt.subplots_adjust(hspace=0, wspace=0)    
    for i in range(nmbMax):
        plt.subplot(8, 8, i + 1)
        if gray_scale:
            plt.imshow((samples[i, :, :, 0] + 1) * 0.5, cmap='gray', aspect='auto')
        else:
            plt.imshow((samples[i, :, :, 0:3] + 1) * 0.5, aspect='auto')
        plt.axis('off')
    plt.savefig(save_loc, bbox_inches = 'tight')
    plt.close()

def save_LS_2D(discriminator_feature_map, batch_size,  kwargs, sample_nr = 2500, X=None, root_dir='plots/', filename='LS_distribution'):
    if not os.path.exists(root_dir):
        os.makedirs(root_dir)
    generated_samples_batch, lev_score_batch, idx_batch = data.sample_batch_LS(batch_size, X, discriminator_feature_map, **kwargs)
    save_loc = os.path.join(root_dir, filename)
    plt.figure(figsize=(5, 5))
    plt.scatter(generated_samples_batch[:, 0], generated_samples_batch[:, 1], c=lev_score_batch)
    plt.colorbar()
    plt.savefig(save_loc, bbox_inches = 'tight')
    plt.clf()
    plt.close()
    
def save_LS_1D(discriminator_feature_map, batch_size, kwargs, sample_nr = 2500, X=None, root_dir='plots/', filename='LS_distribution'):
    if not os.path.exists(root_dir):
        os.makedirs(root_dir)
    # generated_samples_all, lev_score_all, idx_all = sample_batch_LS(X.shape[0], X, discriminator_feature_map, **kwargs)
    generated_samples_batch, lev_score_batch, idx_batch = data.sample_batch_LS(batch_size, X, discriminator_feature_map, **kwargs)
    save_loc = os.path.join(root_dir, filename)
    plt.scatter(generated_samples_batch[:, 0], lev_score_batch, label="X")
    plt.scatter(generated_samples_batch[idx_batch, 0], tf.gather(lev_score_batch,idx_batch),label="Samples")
    plt.yscale('log')
    plt.legend(loc = 'upper right')
    titleName = 'Eff. dim / N: {} / {}'.format(np.int(np.sum(lev_score_batch)),lev_score_batch.shape[0])
    plt.title(titleName)
    plt.savefig(save_loc, bbox_inches = 'tight')
    plt.clf()
    plt.close()
    

    
    
