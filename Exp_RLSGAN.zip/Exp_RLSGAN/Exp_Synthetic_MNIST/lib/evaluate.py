import itertools
import collections
import numpy as np
import tensorflow as tf
import tensorflow_probability as tfp
import tensorflow_hub as hub
import tensorflow_gan as tfgan
import os
from lib import models, data, logging
import math
from scipy.stats import entropy
import matplotlib.pyplot as plt
import matplotlib.style as style 
import matplotlib
import seaborn as sns

# Style
style.use('ggplot')
matplotlib.rcParams['font.family'] = "serif"
sns.set(font='serif')
sns.set_context("poster")  
plt.rc('xtick', labelsize=30)
plt.rc('ytick', labelsize=30)

minimumModesSynthetic = 50


def evaluate_nr_modes_and_high_quality_samples(means, xx, std, root_dir=None, filename='Mode_distribution'):
    l2_store = []
    for x_ in xx:
        l2_store.append([np.sum((x_ - i) ** 2) for i in means])

    mode = np.argmin(l2_store, 1).flatten().tolist()
    dis_ = [l2_store[j][i] for j, i in enumerate(mode)]
    mode_counter = [mode[i] for i in range(len(mode)) if np.sqrt(dis_[i]) <= 3 * std]
    mode_counter_arr = np.array(mode_counter)
    samples_per_mode = np.zeros(means.shape[0])
    nr_modes_captured = 0
    for i in range(means.shape[0]):
        samples_per_mode[i] = np.sum(mode_counter_arr == i)
        if samples_per_mode[i] > minimumModesSynthetic:
            nr_modes_captured = nr_modes_captured + 1
    nr = np.sum(list(collections.Counter(mode_counter).values()))
    percentage_within_3std = nr / xx.shape[0]
    
    if root_dir is not None:
        if not os.path.exists(root_dir):
            os.makedirs(root_dir)
        save_loc = os.path.join(root_dir, filename)
        y_pos = np.arange(len(samples_per_mode))
        plt.bar(y_pos,samples_per_mode)
        if len(y_pos) > 10:
           plt.xticks([], [])
        else:
           plt.xticks(y_pos, y_pos)	
        plt.savefig(save_loc, bbox_inches = 'tight')
        plt.clf()
        plt.close()
    
    return nr_modes_captured, percentage_within_3std, samples_per_mode


def evaluate_grid(xx, std=0.05, root_dir=None):
    means = np.array([np.array([i, j]) for i, j in itertools.product(range(-4, 5, 2), range(-4, 5, 2))],
                     dtype=np.float32)
    return evaluate_nr_modes_and_high_quality_samples(means, xx, std, root_dir=root_dir)


def evaluate_ring(xx, radius=2.5, std=0.05, n_mixture=8, root_dir=None):
    thetas = np.linspace(0, 2 * np.pi, n_mixture + 1)[:-1]
    xs, ys = radius * np.sin(thetas), radius * np.cos(thetas)
    means = np.asarray([np.asarray([xi, yi]) for xi, yi in zip(xs.ravel(), ys.ravel())])
    return evaluate_nr_modes_and_high_quality_samples(means, xx, std, root_dir=root_dir)


def evaluate_row_gaussians(xx, std=0.05, delta_mu=2, num_components=5):
    mus = [(delta_mu * i) for i in range(num_components)]
    mus = (mus - np.mean(mus)).astype('float32')
    mus = [(m, 0) for m in mus]  # row on y=0
    return evaluate_nr_modes_and_high_quality_samples(mus, xx, std)
    
def evaluate_Gaussian(samples):
    # KL
    N = 100
    deltaVal = 30/N
    edges = tf.range(-15, 15 + deltaVal, delta=deltaVal)
    real_samples, probsX = data.sample_Gaussian(samples.shape[0])
    counts_real = tfp.stats.histogram(real_samples, edges) + 1e-6
    counts_fake = tfp.stats.histogram(samples, edges) + 1e-6
    KL = entropy(counts_real,counts_fake)
    
    # PSI
    edges = np.asarray([-15,-12.5,-7.5,-2.5, 2.5, 7.5, 12.5,15]).astype('float32')
    counts_real = tfp.stats.histogram(real_samples, edges) + 1e-6
    counts_fake = tfp.stats.histogram(samples, edges) + 1e-6
    
    #tf.print(counts_real)
    #tf.print(counts_fake)
    
    idx_i = tf.where(counts_real > minimumModesSynthetic)
    counts_real =  tf.gather(counts_real,idx_i)
    counts_fake = tf.gather(counts_fake,idx_i)
    
    n_beta = 100
    beta_all = np.linspace(0, 1,num=n_beta)
    for i in range(beta_all.shape[0]):
        beta = beta_all[i]
        PointwiseConv = tf.math.count_nonzero(counts_fake < beta * counts_real) 
        if PointwiseConv > 0:
            beta_final = beta_all[i-1]
            break
    return KL, beta_final
    
def evaluate_MNIST(samples, true_labels, cnn_mnist_model_location='data/cnn_model_checkpoint.hdf5', batch_size=64, root_dir=None, filename='Mode_distribution', Classes = np.arange(10),minimumModesMNIST = 150):
    cnn = models.mnist_cnn()
    cnn.load_weights(cnn_mnist_model_location)
    nmbClass = len(Classes)
    
    if len(samples.shape) == 2:
        imgSize = np.sqrt(samples.shape[1]).astype(int)
        samples = np.reshape(samples,(samples.shape[0],imgSize,imgSize))
    if len(samples.shape) == 3:
        samples = np.expand_dims(samples, -1)

    channel = np.asarray(cnn.predict(samples, batch_size=batch_size))
    y_pred = np.zeros(channel.shape[0])
    for i in range(channel.shape[0]):
        y_pred[i] = np.argmax(channel[i])
    unique_y_samples = np.unique(y_pred)
    
    samples_per_mode = np.zeros(nmbClass)
    nr_modes_captured = 0
    for i in Classes:
        samples_per_mode[i] = np.sum(y_pred == i)
        if samples_per_mode[i] > minimumModesMNIST:
            nr_modes_captured = nr_modes_captured + 1
    
    if root_dir is not None:
        if not os.path.exists(root_dir):
            os.makedirs(root_dir)
        save_loc = os.path.join(root_dir, filename)
        y_pos = np.arange(len(samples_per_mode))
        plt.bar(y_pos,samples_per_mode)
        if len(y_pos) > 10:
           plt.xticks([], [])
        else:
           plt.xticks(y_pos, y_pos)	
        plt.savefig(save_loc, bbox_inches = 'tight')
        plt.clf()
        plt.close()
        
    samples = np.asarray(samples)
        
    # Visualize classifications
    for i in range(10):
        filename_current = 'Class_' + str(i)
        idx_i = np.argwhere(y_pred == i).flatten()
        if len(idx_i) > 0:
            samples_i = samples[idx_i,:,:,:]
            logging.save_samples_as_images(samples_i, root_dir=root_dir, filename = filename_current)
            
    return nr_modes_captured, sample_KL_divergence(y_pred.astype('int32'),true_labels[:samples.shape[0]], n_unique=nmbClass ,Classes=Classes), samples_per_mode
    


def sample_KL_divergence(a, b, n_unique,Classes = None):
    a_probs = np.zeros(n_unique)
    b_probs = np.zeros(n_unique)

    if Classes is None: 
        for y in a:
            a_probs[y] = a_probs[y] + 1
        for y in b:
            b_probs[y] = b_probs[y] + 1
    else: 
        for y in a:
            for index, item in enumerate(Classes):
                if y == item:
                    a_probs[index] = a_probs[index] + 1
        for y in b:
            for index, item in enumerate(Classes):
                if y == item:
                    b_probs[index] = b_probs[index] + 1

    a_probs = a_probs / (len(a))
    b_probs = b_probs / (len(b))
    a_probs = tf.clip_by_value(a_probs, tf.keras.backend.epsilon(), 1) # prevents NaN or inf because of 0 prob
    b_probs = tf.clip_by_value(b_probs, tf.keras.backend.epsilon(), 1) # prevents NaN or inf because of 0 prob

    X = tfp.distributions.Categorical(probs=a_probs)
    Y = tfp.distributions.Categorical(probs=b_probs)
    return tfp.distributions.kl_divergence(X, Y)


def _resize_images_batch_wise(images, new_size, batch_size, method=tf.image.ResizeMethod.BILINEAR):
    resized_images = np.zeros((images.shape[0], new_size[0], new_size[1], images.shape[3]), dtype='float32')
    curr_index = 0
    while curr_index < images.shape[0]:
        if curr_index + batch_size > images.shape[0]:
            curr_generated_batch = images[curr_index:]
            resized_images[curr_index:] = tf.image.resize(
                curr_generated_batch, [new_size[0], new_size[1]], method=method)
        else:
            curr_batch = images[curr_index:curr_index + batch_size]
            resized_images[curr_index:curr_index + batch_size] = tf.image.resize(
                curr_batch, [new_size[0], new_size[1]], method=method)
        curr_index = curr_index + batch_size
    return resized_images


# Evaluates how well the inceptionv3 network is able to classify the generated images
def inception_score(generated_images, batch_size=32, resize_method = None):
    if resize_method is not None:
        size = tfgan.eval.INCEPTION_DEFAULT_IMAGE_SIZE
        generated_images = _resize_images_batch_wise(generated_images, (size, size), batch_size, method = resize_method)
    num_batches = math.ceil(generated_images.shape[0] / batch_size)
    return tfgan.eval.inception_score(generated_images, num_batches=num_batches)


# In addition to the inception score, a comparison is also made to real images
def frechet_inception_distance(generated_images, x, batch_size=32, resize_method = None):
    if resize_method is not None:
        size = tfgan.eval.INCEPTION_DEFAULT_IMAGE_SIZE
        generated_images = _resize_images_batch_wise(generated_images, (size, size), batch_size, method=resize_method)
        x = _resize_images_batch_wise(x, (size, size), batch_size, method=resize_method)
    num_batches = math.ceil(generated_images.shape[0] / batch_size)
    return tfgan.eval.inception_metrics.frechet_inception_distance(x,generated_images,num_batches=num_batches)








