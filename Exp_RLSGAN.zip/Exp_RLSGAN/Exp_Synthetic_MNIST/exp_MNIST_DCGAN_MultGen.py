from lib.gans import *
from lib import evaluate, models, data,linalg, losses
from timeit import default_timer as timer
import numpy as np
from lib import data
import sys

if __name__ == '__main__':

    # tf.config.set_visible_devices([], 'GPU')


    z_dim = 100
    channels = 1
    x_dim = (28,28,channels)
    inception_batch_size = 1 # batch size used for the inception scores
    x_samples = 10000
    eval_samples = 10000
    batch_size = 64
    steps = 30000
    n_rep = 3
    unbalanced= True
    ratioProb = 0.05
    settingMNIST = int(sys.argv[1])
    if settingMNIST == 1:
        minimumModes = 150
        Classes = [0,1,2]
        UnbalancedClass = [2]
    elif settingMNIST == 2:
        minimumModes = 80
        Classes = [0,1,2,3,4,5,6,7,8,9]
        UnbalancedClass = [0,1,2,3,4]
    nmbClass = len(Classes)
    nmbUnbalanced = len(UnbalancedClass) 
    lambdaRegParam = float(sys.argv[2])
    batchSizeVal = 1
    lr = 1e-3
    sample_cache_nr =  batch_size * batchSizeVal # precalculate n batches - for LS this means only calculate leverage score every x batches. 
    deltas = [0.25]
    nmbGenerators = 15
    s = int(sys.argv[3])
        
    data.setLambdaReg(lambdaRegParam)
    setLearningRate(lr)

    name = 'Results_MNIST_DCGAN_MultGen_ECML_rep3_15_' + str(ratioProb).replace('.', '') + '_' + str(settingMNIST) + '_' + str(data.getLambdaReg()).replace('.', '') + '_' + str(lr).replace('.', '') + '_' + str(s) 
    nameDir = 'MNIST_DCGAN_MultGen_ECML_rep3_15_' + str(ratioProb).replace('.', '') + '_' + str(settingMNIST) + '_' + str(data.getLambdaReg()).replace('.', '') + '_' + str(lr).replace('.', '') + '_' + str(s) 

    if os.path.exists(name):
        os.remove(name)


    def write_to_console_file(txt):
        with open(name, 'a') as f:
            f.write(txt + '\n')
            print(txt)


    def create_gan_models():
        GANlist = []
        GANlist.append(lambda: MWUGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
               models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels, output_activation='sigmoid'), 
               nmbGenerators = nmbGenerators, delta = 0.25, discriminator_loss=losses.cross_entropy_discriminator_loss_sigmoid, 
               generator_loss=losses.cross_entropy_generator_sigmoid, weights = 'mnist_sketched', weightedLoss = False, sigma = s,nameDataset = 'MNIST',
               Classes=Classes,labelsTrue=labelsTrue,minimumModes = minimumModes)) # sigmoid output and sigmoid loss function 
        GANlist.append(lambda: MWUGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
               models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels, output_activation='sigmoid'), 
               nmbGenerators = nmbGenerators, delta = 0.25, discriminator_loss=losses.cross_entropy_discriminator_loss_sigmoid, 
               generator_loss=losses.cross_entropy_generator_sigmoid, weights = 'mnist_UMAP', weightedLoss = False, sigma = s,nameDataset = 'MNIST',
               Classes=Classes,labelsTrue=labelsTrue,minimumModes = minimumModes)) # sigmoid output and sigmoid loss function    
        GANlist.append(lambda: MWUGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels),
               models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels, output_activation='sigmoid'), 
               nmbGenerators = nmbGenerators, delta = 0.25, discriminator_loss=losses.cross_entropy_discriminator_loss_sigmoid, 
               generator_loss=losses.cross_entropy_generator_sigmoid,nameDataset = 'MNIST',Classes=Classes,labelsTrue=labelsTrue,minimumModes = minimumModes)) # sigmoid output and sigmoid loss function 
        return GANlist

    MNIST_results = {}
    intermediate_results_mode = np.zeros((5,nmbGenerators,n_rep))
    intermediate_results_KL = np.zeros((5,nmbGenerators,n_rep))
    
    x, labels, probX = data.sample_MNIST(unbalanced,ratioProb,UnbalancedClass,Classes)
    _, labelsTrue,_ = data.sample_MNIST(False,ratioProb,UnbalancedClass,Classes)
    
    samples_per_mode = np.zeros(nmbClass)
    for i in range(nmbClass):
        samples_per_mode[i] = np.sum(labels == Classes[i])
    samples_per_mode = samples_per_mode / np.sum(samples_per_mode)
    write_to_console_file('Exp. samples: {}'.format(samples_per_mode * eval_samples))

    ### MNIST ###
    for i in range(n_rep):
        gans = create_gan_models()
        
        GAN_counter = 0

        for gan_f in gans:
            gan = gan_f()
            write_to_console_file('---- ' + gan.name + ' ----')
            start = timer()
            gan.train(x, batch_size=batch_size, steps=steps, save_samples_every=1000, log_losses=False,
                      logdir=nameDir, probX = probX, Classes=Classes, labelsTrue = labelsTrue)
            end = timer()
            time = (end - start)
            samples = gan.sample_generator(eval_samples)
            nr_modes_captured, KL_div, samples_per_mode = evaluate.evaluate_MNIST(samples,labelsTrue,root_dir=os.path.join(nameDir, gan.name),Classes=Classes,minimumModesMNIST = minimumModes)
            write_to_console_file('Number of Modes Captured: {}'.format(nr_modes_captured))
            write_to_console_file('KL: {}'.format(KL_div))
            write_to_console_file('Samples per Mode: {}'.format(samples_per_mode))

            if gan.name not in MNIST_results:
                MNIST_results[gan.name] = []
            tmp = np.zeros(3+len(samples_per_mode))
            tmp[0] = nr_modes_captured
            tmp[1] = KL_div
            tmp[2] = time
            tmp[3:] = samples_per_mode
            MNIST_results[gan.name].append(tmp)
            
            # Intermediate
            intermediate_results_mode[GAN_counter,:,i] = gan.nr_modes_captured
            intermediate_results_KL[GAN_counter,:,i] = gan.perc_std
            GAN_counter += 1

            tf.keras.backend.clear_session()  # free memory
            del gan

        del gans
        
        
    # Print intermediate results
    np.save(os.path.join(nameDir,'intermediate_results_mode.npy'), intermediate_results_mode) # save
    np.save(os.path.join(nameDir,'intermediate_results_KL.npy'), intermediate_results_KL) # save
    Mode_mean = np.mean(intermediate_results_mode,axis=2)
    Mode_std = np.std(intermediate_results_mode,axis=2)
    Perc_mean = np.mean(intermediate_results_KL,axis=2)
    Perc_std = np.std(intermediate_results_KL,axis=2)
    x = np.arange(1,nmbGenerators+1)
    method_List = ['LS', 'Unif']
    
    plt.figure()
    for i_method in range(4):
        plt.plot(x,Mode_mean[i_method,:])
        plt.fill_between(x, Mode_mean[i_method,:] - Mode_std[i_method,:], Mode_mean[i_method,:] + Mode_std[i_method,:],alpha = 0.3)
    plt.legend(method_List)
    plt.savefig(os.path.join(nameDir, 'Mode_cov'), bbox_inches = 'tight')
    plt.clf()
    plt.close()
    
    plt.figure()
    for i_method in range(4):
        plt.plot(x,Perc_mean[i_method,:])
        plt.fill_between(x, Perc_mean[i_method,:] - Perc_std[i_method,:], Perc_mean[i_method,:] + Perc_std[i_method,:],alpha = 0.3)
    plt.legend(method_List)
    plt.savefig(os.path.join(nameDir, 'KL'), bbox_inches = 'tight')
    plt.clf()
    plt.close()

    for k, v in MNIST_results.items():
        write_to_console_file('\n FINAL RESULTS MNIST' + k)
        arr = np.asarray(v)
        means = np.mean(arr, axis=0)
        stds = np.std(arr, axis=0)

        write_to_console_file('Number of Modes Captured: {}({})'.format(means[0], stds[0]))
        write_to_console_file('Samples per Mode: {} ({})'.format(means[3:], stds[3:]))
        write_to_console_file('KL: {}({})'.format(means[1], stds[1]))
        write_to_console_file('training time: {}({})'.format(means[2], stds[2]))

  
