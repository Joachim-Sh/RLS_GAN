from lib.gans import *
from lib import evaluate, models, data,linalg, losses
from timeit import default_timer as timer
import numpy as np
from lib import data
import sys


if __name__ == '__main__':

    # tf.config.set_visible_devices([], 'GPU')


    z_dim = 25
    x_dim = 2
    x_samples = 10000
    eval_samples = 10000
    batch_size = 64
    steps =  30000
    n_rep =  10
    unbalanced= True
    ratio = 0.05
    nmbUnbalanced = 4
    batchSizeVal = 1
    lambdaRegParam = float(sys.argv[1])
    lr = 1e-3
    sample_cache_nr =  batch_size * batchSizeVal # precalculate n batches - for LS this means only calculate leverage score every x batches. 
    nmbGenerators = 15
    
    data.setLambdaReg(lambdaRegParam)
    setLearningRate(lr)
    

    name = 'Results_Ring_MultGen_' + str(nmbUnbalanced).replace('.', '') + '_' + str(ratio).replace('.', '') + '_' + str(steps) + '_' + str(data.getLambdaReg()).replace('.', '') + '_' + str(lr).replace('.', '')
    nameDir = 'Ring_MultGen_' + str(nmbUnbalanced).replace('.', '')+ '_' + str(ratio).replace('.', '') + '_' + str(steps) + '_' + str(data.getLambdaReg()).replace('.', '') +  '_' + str(lr).replace('.', '')

    if os.path.exists(name):
        os.remove(name)


    def write_to_console_file(txt):
        with open(name, 'a') as f:
            f.write(txt + '\n')
            print(txt)
            
    def create_gan_models():
        GANlist = []
        GANlist.append(lambda: MWUGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), 
            models.fully_connected_discriminator_model(x_dim=x_dim, return_feature_map=True, output_activation='sigmoid'), 
            nmbGenerators = nmbGenerators, delta = 0.25, discriminator_loss=losses.cross_entropy_discriminator_loss_sigmoid, 
            generator_loss=losses.cross_entropy_generator_sigmoid, weights = 'gaussian', weightedLoss = False, sigma = 0.15,nameDataset = 'Ring')) # sigmoid output + loss
        GANlist.append(lambda: MWUGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), 
            models.fully_connected_discriminator_model(x_dim=x_dim,return_feature_map=True, output_activation='sigmoid'), 
            nmbGenerators = nmbGenerators, delta = 0.25, discriminator_loss=losses.cross_entropy_discriminator_loss_sigmoid, 
            generator_loss=losses.cross_entropy_generator_sigmoid,nameDataset = 'Ring')) # sigmoid output + loss
        return GANlist

    ring_results = {}
    intermediate_results_mode = np.zeros((2,nmbGenerators,n_rep))
    intermediate_results_perc = np.zeros((2,nmbGenerators,n_rep))

    ### RING ###
    for i in range(n_rep):
        gans = create_gan_models()
        x, probs, probX = data.sample_ring(x_samples,unbalanced = unbalanced, nmbUnbalanced = nmbUnbalanced, ratio = ratio)
        
        if i == 0:
            write_to_console_file('Exp. samples: {}'.format(probs * eval_samples))
            write_to_console_file('nmbUnbalanced: {}'.format(nmbUnbalanced))
            write_to_console_file('ratio: {}'.format(ratio))
            write_to_console_file('Lambda: {}'.format(data.getLambdaReg()))
            
        GAN_counter = 0

        for gan_f in gans:
            gan = gan_f()
            write_to_console_file('---- ' + gan.name + ' ----')
            start = timer()
            gan.train(x, batch_size=batch_size, steps=steps, save_samples_every=1000, log_losses=False,
                      logdir=nameDir, probX = probX)
            end = timer()
            time = (end - start)
            samples = gan.sample_generator(eval_samples)
            nr_modes_captured, percentage_within_3std, samples_per_mode = evaluate.evaluate_ring(samples,root_dir=os.path.join(nameDir, gan.name))
            write_to_console_file('Number of Modes Captured: {}'.format(nr_modes_captured))
            write_to_console_file('Samples per Mode: {}'.format(samples_per_mode))
            write_to_console_file('Number of Points Falling Within 3 std. of the Nearest Mode {}/{} = {}'
                                  .format(percentage_within_3std * eval_samples, eval_samples, percentage_within_3std))

            if gan.name not in ring_results:
                ring_results[gan.name] = []
            tmp = np.zeros(3+len(samples_per_mode))
            tmp[0] = nr_modes_captured
            tmp[1] = percentage_within_3std
            tmp[2] = time
            tmp[3:] = samples_per_mode
            ring_results[gan.name].append(tmp)
            
            # Intermediate
            intermediate_results_mode[GAN_counter,:,i] = gan.nr_modes_captured
            intermediate_results_perc[GAN_counter,:,i] = gan.perc_std
            GAN_counter += 1

            tf.keras.backend.clear_session()  # free memory
            del gan

        del gans
        
    # Print intermediate results
    Mode_mean = np.mean(intermediate_results_mode,axis=2)
    Mode_std = np.std(intermediate_results_mode,axis=2)
    Perc_mean = np.mean(intermediate_results_perc,axis=2)
    Perc_std = np.std(intermediate_results_perc,axis=2)
    x = np.arange(1,nmbGenerators+1)
    method_List = ['RLS', 'Unif']
    
    plt.figure()
    for i_method in range(2):
        plt.plot(x,Mode_mean[i_method,:])
        plt.fill_between(x, Mode_mean[i_method,:] - Mode_std[i_method,:], Mode_mean[i_method,:] + Mode_std[i_method,:],alpha = 0.3)
    plt.legend(method_List)
    plt.savefig(os.path.join(nameDir, 'Mode_cov'), bbox_inches = 'tight')
    plt.clf()
    plt.close()
    
    plt.figure()
    for i_method in range(2):
        plt.plot(x,Perc_mean[i_method,:])
        plt.fill_between(x, Perc_mean[i_method,:] - Perc_std[i_method,:], Perc_mean[i_method,:] + Perc_std[i_method,:],alpha = 0.3)
    plt.legend(method_List)
    plt.savefig(os.path.join(nameDir, 'Perc_std'), bbox_inches = 'tight')
    plt.clf()
    plt.close()

    for k, v in ring_results.items():
        write_to_console_file('\n FINAL RESULTS RING' + k)
        arr = np.asarray(v)
        means = np.mean(arr, axis=0)
        stds = np.std(arr, axis=0)

        write_to_console_file('Number of Modes Captured: {} +- {}'.format(means[0], stds[0]))
        write_to_console_file('Samples per Mode: {} +- {}'.format(means[3:], stds[3:]))
        write_to_console_file('Number of Points Falling Within 3 std. of the Nearest Mode {}/{} = {} +- {}'
                              .format(means[1] * eval_samples, eval_samples, means[1], stds[1]))
        write_to_console_file('training time {} +- {}'.format(means[2], stds[2]))

  
