from lib.gans import *
from lib import evaluate, models, data,linalg, losses
from timeit import default_timer as timer
import numpy as np
from lib import data
import sys

if __name__ == '__main__':

    # tf.config.set_visible_devices([], 'GPU')
    #os.environ["CUDA_VISIBLE_DEVICES"] = "0"    
    

    z_dim = 25
    x_dim = 2
    x_samples = 10000
    eval_samples = 10000
    batch_size = 64
    steps = 30000
    n_rep = 1
    unbalanced= True
    ratio = 0.05
    nmbUnbalanced = 10
    lambdaRegParam = float(sys.argv[1])
    batchSizeVal = 1
    lr = 1e-3
    sample_cache_nr =  batch_size * batchSizeVal # precalculate n batches - for LS this means only calculate leverage score every x batches. 
    deltas = [0.25]
    nmbGenerators = 15

    
    data.setLambdaReg(lambdaRegParam)
    setLearningRate(lr)

    name = 'Results_Grid_' + str(nmbUnbalanced).replace('.', '') + '_' + str(ratio).replace('.', '') + '_' + str(steps) + '_' + str(data.getLambdaReg()).replace('.', '') + '_' + str(lr).replace('.', '')
    nameDir = 'Grid_' + str(nmbUnbalanced).replace('.', '')+ '_' + str(ratio).replace('.', '') + '_' + str(steps) + '_' + str(data.getLambdaReg()).replace('.', '') + '_' + str(lr).replace('.', '')
    

    if os.path.exists(name):
        os.remove(name)


    def write_to_console_file(txt):
        with open(name, 'a') as f:
            f.write(txt + '\n')
            print(txt)


    def create_gan_models():
        GANlist = []
        GANlist.append(lambda: IWGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(x_dim=x_dim, 
            return_feature_map=True), name='IWGAN',x_sampler_method='npuniform', estimator = 'iw'))
        GANlist.append(lambda: IWMMDGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(x_dim=x_dim, 
            return_feature_map=True), name='IWMMDGAN',x_sampler_method='npuniform'))
        GANlist.append(lambda: GAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(x_dim=x_dim, 
            return_feature_map=True), name='GAN_normal',x_sampler_method='npuniform'))
        GANlist.append(lambda: BuresGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(x_dim=x_dim,    
            return_feature_map=True), name='Bures',x_sampler_method='npuniform', sample_cache_nr = sample_cache_nr))
        GANlist.append(lambda: BuresGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(x_dim=x_dim,    
            return_feature_map=True), x_sampler_method='ls', sample_cache_nr = sample_cache_nr,
            x_sampler_args= {"featuremapSampling":"discriminator","twoStep":20}, weightedLoss = False))
        GANlist.append(lambda: BuresGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(x_dim=x_dim,    
            return_feature_map=True) ,x_sampler_method='ls', sample_cache_nr = sample_cache_nr,
            x_sampler_args= {"featuremapSampling":"gaussian","bw": 0.15,"twoStep":20}, weightedLoss = False))
        GANlist.append(lambda: PACGAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(
            x_dim=x_dim * 2, return_feature_map=True),pack_nr=2, name='PACGAN2',x_sampler_method='npuniform',sample_cache_nr = sample_cache_nr))
        GANlist.append(lambda: GAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(
            x_dim=x_dim, return_feature_map=True),x_sampler_method='ls',sample_cache_nr = sample_cache_nr, 
            x_sampler_args= {"featuremapSampling":"discriminator","twoStep":20}, weightedLoss = False))
        GANlist.append(lambda: GAN(models.fully_connected_generator_model(z_dim=z_dim, x_dim=x_dim), models.fully_connected_discriminator_model(
            x_dim=x_dim, return_feature_map=True),x_sampler_method='ls',sample_cache_nr = sample_cache_nr, 
            x_sampler_args= {"featuremapSampling":"gaussian","bw": 0.15, "twoStep" : 20}, weightedLoss = False))
        return GANlist

    grid_results = {}

    ### GRID ###

    write_to_console_file('\n **** GRID ****')

    for i in range(n_rep):
        gans = create_gan_models()
        x,probs, probX = data.sample_grid(x_samples,unbalanced=True,  nmbUnbalanced = nmbUnbalanced, ratio = ratio)
        
        if i == 0:
            write_to_console_file('Exp. samples: {}'.format(probs * eval_samples))
            write_to_console_file('nmbUnbalanced: {}'.format(nmbUnbalanced))
            write_to_console_file('ratio: {}'.format(ratio))
            write_to_console_file('Lambda: {}'.format(data.getLambdaReg()))

        for gan_f in gans:
            gan = gan_f()
            write_to_console_file('---- ' + gan.name + ' ----')
            start = timer()
            gan.train(x, batch_size=batch_size, steps=steps, save_samples_every=1000, log_losses=False,
                      logdir=nameDir, probX = probX)
            end = timer()
            time = (end - start)
            samples = gan.sample_generator(eval_samples)
            nr_modes_captured, percentage_within_3std, samples_per_mode = evaluate.evaluate_grid(samples,root_dir=os.path.join(nameDir, gan.name))
            write_to_console_file('Number of Modes Captured: {}'.format(nr_modes_captured))
            write_to_console_file('Samples per Mode: {}'.format(samples_per_mode))
            write_to_console_file('Number of Points Falling Within 3 std. of the Nearest Mode {}/{} = {}'
                                  .format(percentage_within_3std * eval_samples, eval_samples, percentage_within_3std))

            if gan.name not in grid_results:
                grid_results[gan.name] = []
            tmp = np.zeros(3+len(samples_per_mode))
            tmp[0] = nr_modes_captured
            tmp[1] = percentage_within_3std
            tmp[2] = time
            tmp[3:] = samples_per_mode
            grid_results[gan.name].append(tmp)

            tf.keras.backend.clear_session()  # free memory
            del gan

        del gans

    for k, v in grid_results.items():
        write_to_console_file('\n FINAL RESULTS GRID' + k)
        arr = np.asarray(v)
        means = np.mean(arr, axis=0)
        stds = np.std(arr, axis=0)

        write_to_console_file('Number of Modes Captured: {} +- {}'.format(means[0], stds[0]))
        write_to_console_file('Samples per Mode: {} +- {}'.format(means[3:], stds[3:]))
        write_to_console_file('Number of Points Falling Within 3 std. of the Nearest Mode {}/{} = {}({})'
                              .format(means[1] * eval_samples, eval_samples, means[1], stds[1]))
        write_to_console_file('training time {} +- {}'.format(means[2], stds[2]))
