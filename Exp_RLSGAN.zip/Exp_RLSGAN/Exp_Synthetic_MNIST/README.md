# Leverage Score Sampling for Complete Mode Coverage in Generative Adversarial Networks
This repository contains the code used in the experiments for the paper "Leverage Score Sampling for Complete Mode Coverage in Generative Adversarial Networks".

## Requirements
Experiments have been run on given versions but it is often not required to run with the exact same package versions.
- Tensorflow 2.2.0
  - tensorflow-probability   0.10.0
  - tensorflow-hub           0.8.0
  - tensorflow-gan           2.0.0
- tqdm 4.41.1
- matplotlib               3.2.1
- umap-learn

## Usage
The scripts used in the **evaluations** experiments are the following:

 - syn_Grid.py
 - syn_Ring.py
 - syn_Grid_MultGen.py
 - syn_Ring_MultGen.py
 - exp_MNIST_DCGAN.py
 - exp_MNIST_DCGAN_MultGen.py


The synthetic experiments are run with a single parameter: the regularization parameter of the RLSs
	
    python syn_Grid.py 1e-3

The MNIST experiments are run with 3 parameters: the dataset [1 = unbalanced 012-MNIST or 2 = unbalanced MNIST], the regularization parameter of the RLSs and the size if the dimension reduction
	
    python exp_MNIST_DCGAN.py 1 1e-4 25

