from lib.gans import *
from lib import evaluate, models, data,linalg, losses
from timeit import default_timer as timer
import numpy as np
from lib import data
import sys

if __name__ == '__main__':

    # tf.config.set_visible_devices([], 'GPU')


    z_dim = 100
    channels = 1
    x_dim = (28,28,channels)
    inception_batch_size = 1 # batch size used for the inception scores
    x_samples = 10000
    eval_samples = 10000
    batch_size = 64
    steps = 30000
    n_rep = 10
    unbalanced= True
    ratioProb = 0.05
    settingMNIST = int(sys.argv[1])
    if settingMNIST == 1:
        minimumModes = 150
        Classes = [0,1,2]
        UnbalancedClass = [2]
    elif settingMNIST == 2:
        minimumModes = 80
        Classes = [0,1,2,3,4,5,6,7,8,9]
        UnbalancedClass = [0,1,2,3,4]
    nmbClass = len(Classes)
    nmbUnbalanced = len(UnbalancedClass) 
    lambdaRegParam = float(sys.argv[2])
    batchSizeVal = 1
    lr = 1e-3
    sample_cache_nr =  batch_size * batchSizeVal # precalculate n batches - for LS this means only calculate leverage score every x batches. 
    deltas = [0.25]
    s = int(sys.argv[3])
    
    data.setLambdaReg(lambdaRegParam)
    setLearningRate(lr)

    name = 'Results_MNIST_DCGAN_IWMMD_' + str(steps).replace('.', '') + '_' + str(settingMNIST) + '_' + str(data.getLambdaReg()).replace('.', '') + '_' + str(lr).replace('.', '') + '_' + str(s) 
    nameDir = 'MNIST_DCGAN_IWMMD_' + str(steps).replace('.', '') + '_' + str(settingMNIST) + '_' + str(data.getLambdaReg()).replace('.', '') + '_' + str(lr).replace('.', '') + '_' + str(s) 

    if os.path.exists(name):
        os.remove(name)


    def write_to_console_file(txt):
        with open(name, 'a') as f:
            f.write(txt + '\n')
            print(txt)


    def create_gan_models():
        GANlist = []
        GANlist.append(lambda: IWGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels), name='IWGAN',x_sampler_method='npuniform'))
        GANlist.append(lambda: IWMMDGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels,output_activation = None), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels), name='IWMMDGAN',x_sampler_method='npuniform'))
        GANlist.append(lambda: GAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels), name='GAN_normal',x_sampler_method='npuniform'))
        GANlist.append(lambda: BuresGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels), name='Bures',x_sampler_method='npuniform', 
        sample_cache_nr = sample_cache_nr))
        GANlist.append(lambda: BuresGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels), x_sampler_method='ls', sample_cache_nr = sample_cache_nr,
            x_sampler_args= {"featuremapSampling":"discriminator_sketched","twoStep":20,"s":s}, weightedLoss = False))
        GANlist.append(lambda: BuresGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels), x_sampler_method='ls', sample_cache_nr = sample_cache_nr,
            x_sampler_args= {"featuremapSampling":"mnist_sketched","twoStep":20,"s":s}, weightedLoss = False))
        GANlist.append(lambda: BuresGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels=channels), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels=channels), x_sampler_method='ls', sample_cache_nr = sample_cache_nr,
            x_sampler_args= {"featuremapSampling":"mnist_UMAP","twoStep":20,"s":s}, weightedLoss = False))
        GANlist.append(lambda: PACGAN(models.mnist_dcgan_generator_model(z_dim=z_dim, channels= channels), 
        models.mnist_dcgan_discriminator_model(return_feature_map=True, channels= 2 *channels),pack_nr=2, name='PACGAN2',
        x_sampler_method='npuniform',sample_cache_nr = sample_cache_nr))
        return GANlist

    MNIST_results = {}
    
    x, labels, probX = data.sample_MNIST(unbalanced,ratioProb,UnbalancedClass,Classes)
    _, labelsTrue,_ = data.sample_MNIST(False,ratioProb,UnbalancedClass,Classes)
    
    samples_per_mode = np.zeros(nmbClass)
    for i in range(nmbClass):
        samples_per_mode[i] = np.sum(labels == Classes[i])
    samples_per_mode = samples_per_mode / np.sum(samples_per_mode)
    write_to_console_file('Exp. samples: {}'.format(samples_per_mode * eval_samples))

    ### MNIST ###
    for i in range(n_rep):
        gans = create_gan_models()

        for gan_f in gans:
            gan = gan_f()
            write_to_console_file('---- ' + gan.name + ' ----')
            start = timer()
            gan.train(x, batch_size=batch_size, steps=steps, save_samples_every=1000, log_losses=False,
                      logdir=nameDir, probX = probX)
            end = timer()
            time = (end - start)
            samples = gan.sample_generator(eval_samples)
            nr_modes_captured, KL_div, samples_per_mode = evaluate.evaluate_MNIST(samples,labelsTrue,root_dir=os.path.join(nameDir, gan.name),Classes=Classes,minimumModesMNIST = minimumModes)
            write_to_console_file('Number of Modes Captured: {}'.format(nr_modes_captured))
            write_to_console_file('KL: {}'.format(KL_div))
            write_to_console_file('Samples per Mode: {}'.format(samples_per_mode))

            if gan.name not in MNIST_results:
                MNIST_results[gan.name] = []
            tmp = np.zeros(3+len(samples_per_mode))
            tmp[0] = nr_modes_captured
            tmp[1] = KL_div
            tmp[2] = time
            tmp[3:] = samples_per_mode
            MNIST_results[gan.name].append(tmp)

            tf.keras.backend.clear_session()  # free memory
            del gan

        del gans

    for k, v in MNIST_results.items():
        write_to_console_file('\n FINAL RESULTS MNIST' + k)
        arr = np.asarray(v)
        means = np.mean(arr, axis=0)
        stds = np.std(arr, axis=0)

        write_to_console_file('Number of Modes Captured: {}({})'.format(means[0], stds[0]))
        write_to_console_file('Samples per Mode: {}({})'.format(means[3:], stds[3:]))
        write_to_console_file('KL: {}({})'.format(means[1], stds[1]))
        write_to_console_file('training time: {}({})'.format(means[2], stds[2]))

  
